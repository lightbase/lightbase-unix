#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"
#include  "lb2vet.h"

#include  <string.h>
#include  <ctype.h>

#ifdef MSDOS
#include  <mem.h>
#include  <dir.h>
#include  <io.h>
long farcoreleft(void);
TEXT   *w_memmove( TEXT *, TEXT *, US );
#else
TEXT   *w_memmove( );
#endif

#include  "../../ct/cteproto.h"
#include  "../../ct/ctdefs.h"
#include  "../../ct/cterrc.h"

COUNT ap_sizeio = (UCOUNT)65000L;
COUNT ap_extravet = 0;
COUNT repro1_5 = 99;
COUNT depura;
COUNT release;
COUNT ap_mxelem;

COUNT mapeia_cv, mapa_cv[300];

Base        rec_base, *WBS;
POINTER     lb4_pos;
Base        *v_bases[2];
Desc_base   *c_bases[2], dbase, *WCB;

Vet_itens   *v_campos[2];
Vista       ap_vista;
Rel         ap_rel;
TEXT        *buf_iotxt; /* buffer para io de texto e load_vet */
COUNT       lb4_old,
            lb4_new;
LONG        num_serie;
UCOUNT       id_arq;

TEXT novo_arquivo[60];

struct hdtxt {
   UTEXT txt_marca;
   LONG  txt_record;
   UTEXT txt_campo;
   UTEXT txt_parte;
   POINTER txt_proximo;
} *p_hdtxt;

POINTER pos_hdr;
POINTER pos_stp;
POINTER pos_campos;
POINTER pos_vistas;
POINTER pos_relats;
POINTER pos_ivis[MAX_VISTAS+2];
POINTER pos_irel[MAX_VISTAS+2];
COUNT indvis, indrel;
FILE *fp_exp;
COUNT order;

Vet_itens *v;

#define     MARCA_REGISTRO 254
#define     MARCA_TEXTO    255

/* #define     BASE_EDIT  0 */

#define   MAX(x,y)        (((x)>(y))?(x):(y))
#define   MIN(x,y)        (((x)<(y))?(x):(y))
#define   debug(x)        fprintf(stderr, "%s\n", x);

#define   BS  'B'
#define   CP  'C'
#define   VS  'V'
#define   IV  'I'
#define   RE  'R'
#define   IR  'L'
#define   SW  'S'

#define     CAMPO_G 'G'  /*** CAMPO GENERICO - ENTRADA ou SAIDA ***/
#define     CAMPO_S 'S'
#define     CAMPO_E 'E'

#ifdef MSDOS
   COUNT analiza_velho(VOID);
   COUNT ident_reg( TEXT *, UCOUNT, COUNT *);
   VOID cria_novo(TEXT *);
   COUNT trata_conteudo(VOID);
   COUNT recupera_campos( VOID );
   COUNT consiste_vistas( VOID );
   COUNT consiste_relats( VOID );
   POINTER salva_itens(Vet_itens *);
   VOID vs_cvcampo(Vet_itens *);
   VOID rl_cvcampo(Vet_itens *);
   COUNT e_versao5(TEXT *);
   VOID cv_exit( COUNT );
#else
   COUNT analiza_velho( );
   COUNT ident_reg( );
   VOID cria_novo( );
   COUNT trata_conteudo( );
   COUNT recupera_campos( );
   COUNT consiste_vistas( );
   COUNT consiste_relats( );
   POINTER salva_itens( );
   VOID vs_cvcampo( );
   VOID rl_cvcampo( );
   COUNT e_versao5( );
   VOID cv_exit( );
#endif



#ifdef MSDOS
   /** lb2but1    ***********************************************************/
   Campo **pos_vetcmp(COUNT);
   COUNT qtd_vetcmp(COUNT);
   Vet_itens *load_campos(COUNT, COUNT);
   VOID rlse_campos(COUNT);
   COUNT acha_campo(COUNT, COUNT);
   COUNT ver_campo(COUNT, TEXT *, COUNT *);
   TEXT *sel_campo(COUNT, Campo **, COUNT);
   Vet_itens *load_vistas(COUNT, COUNT);
   Vet_itens *load_itvis(Vista *, COUNT);
   TTela *pos_itvis(COUNT);
   COUNT qtd_itvis(VOID);
   Vet_itens *load_rels(COUNT, COUNT);
   Vet_itens *load_itrel(Rel *, COUNT);
   RTela *pos_itrel(COUNT);
   COUNT qtd_itrel(VOID);
#else
   Campo **pos_vetcmp( );
   COUNT qtd_vetcmp( );
   Vet_itens *load_campos( );
   VOID rlse_campos( );
   COUNT acha_campo( );
   COUNT ver_campo( );
   TEXT *sel_campo( );
   Vet_itens *load_vistas( );
   Vet_itens *load_itvis( );
   TTela *pos_itvis( );
   COUNT qtd_itvis( );
   Vet_itens *load_rels( );
   Vet_itens *load_itrel( );
   RTela *pos_itrel( );
   COUNT qtd_itrel( );
#endif



/* Funcoes para padronizar gravacao/leitura de LONG na memoria */
#ifndef PUT_LONG
F__GLB   VOID PUT_LONG(p, l)
UTEXT *p;
LONG l;
{  UTEXT *pc;

   pc = (UTEXT*)&l;

   *p++ = *pc++;
   *p++ = *pc++;
   *p++ = *pc++;
   *p = *pc;
}
#endif



#ifndef GET_LONG
F__GLB   LONG GET_LONG(p)
UTEXT *p;
{  LONG l;
   UTEXT *pc;
   pc = (UTEXT*)&l;

   *pc++ = *p++;
   *pc++ = *p++;
   *pc++ = *p++;
   *pc = *p;
   return(l);
}
#endif


TEXT  *w_memmove( dest, orig, tam )

TEXT  *dest, *orig;
US  tam;
{
   US   I;
   register TEXT   *A, *B;

   A = dest;
   B = orig;

   if ( A > B )
   {
      A += tam - 1;
      B += tam - 1;

      for ( I = 0;   I < tam;   I++ )   *A-- = *B--;
   }

   else
   {
      for ( I = 0;   I < tam;   I++ )   *A++ = *B++;
   }

   return ( orig );
}




main(argc, argv)
int argc;
char **argv;
{  COUNT ret, i;
   TEXT arquivo[60], base[30], backup[30];

   ap_mxelem = MAX_ELEM;


   WBS = v_bases[0] = &rec_base;
   WCB = c_bases[0] = &dbase;
   c_bases[0]->cb_tpopen = 0;
   novo_arquivo[0] = '\0';


#ifdef ESPANHA
   printf("Conversor de Base de datos para version 1.8\n");
   printf("Version 3.4\n");
   printf("Sistemas Soluciones Informatica SL\n\n\n");
#else
   printf("Conversor de Base de dados para versao 1.8\n");
   printf("Versao 3.4\n");
   printf("Light Software Ltda\n\n\n");
#endif

   base[0] = '\0';

   for ( i=1; i < argc; i++ ) {
       if ( argv[i][0] != '-' ) {
          strcpy(base, argv[i]);
          continue;
       }
       switch(argv[i][1]) {
          case '5' : /*  */
   	   	     repro1_5 = 1;
                     break;
          case 'd' : /*  */
          case 'D' : /*  */
      	             depura = 1;
                     break;
          case 'R' : /*  */
          case 'r' : /*  */
      	             mapeia_cv = 1;
                      break;
       }
   }

   if ( base[0] == '\0'  ) {
#ifdef ESPANHA
      printf("Base que sera convertida : ");
#else
      printf("Base a ser convertida : ");
#endif

      gets(base);
   }


   printf("Base %s\n", base);

   if ( base[0] == '\0' )
      cv_exit(0);

   strcpy(arquivo, base);
   strcat(arquivo, ".lb4");
   if ( access(arquivo, 0) != 0 ) {
#ifdef ESPANHA
      printf("Fichero de descripcion de la base no existe.\n");
#else
      printf("Arquivo de descricao da base nao existe.\n");
#endif
      cv_exit(1);
   }


   strcpy(novo_arquivo, "CVXXXXXX");

   if ( mktemp(novo_arquivo) == NULL ) {
#ifdef ESPANHA
      printf("Error en la creacion del fichero temporario\n");
#else
      printf("falha na criacao de arquivo temporario\n");
#endif
      novo_arquivo[0] = '\0';
      cv_exit(2);
   }


   if ( INTREE(6, 5, 8) ) {
#ifdef ESPANHA
      fprintf(stderr, "No inicializo CT\n");
#else
      fprintf(stderr, "Nao inicializou CT\n");
#endif
      cv_exit(1);
   }


   lb4_old = 1;
   lb4_new = 2;


   /* faz com que MANUT_OPEN so sete as variaveis abaixo e mantenha arquivo fechado */
   num_serie = 0L;
   id_arq = 999;

   MANUT_OPEN( lb4_old, arquivo, 'V', &num_serie, &id_arq );

   if ( uerr_cod != IDBASE_ERR ) {
#ifdef ESPANHA
      fprintf(stderr, "Fichero da�ado. No puedo abrirlo. Error : %d\n", uerr_cod);
      fprintf(stderr, "Haga contacto con su distribuidor\n");
#else
      fprintf(stderr, "Arquivo danificado. Nao posso abrir. Erro : %d\n", uerr_cod);
      fprintf(stderr, "Contacte seu revendedor\n");
#endif
      cv_exit(1);
   }


   ret = MANUT_OPEN( lb4_old, arquivo, 'V', &num_serie, &id_arq );

   if ( ret != FCRP_ERR && ret != NO_ERROR ) {
#ifdef ESPANHA
      fprintf(stderr, "Atencion. Error No : %d . Avise a su distribuidor\n", 18);
#else
      fprintf(stderr, "Atencao. Erro No : %d . Reporte ao fornecedor\n", 18);
#endif
      cv_exit(2);
   }

#ifdef ESPANHA
   printf("Version de la base : %d\n", rec_base.bs_versao);
#else
   printf("Versao da base : %d\n", rec_base.bs_versao);
#endif


   if ( (buf_iotxt = malloc((UCOUNT)65000L)) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Sin Memoria");
#else
      fprintf(stderr, "Sem Memoria");
#endif
      ret = -1;
      cv_exit(9);
   }



   analiza_velho();


   cria_novo(novo_arquivo);

   trata_conteudo();


#ifdef MSDOS
   if ( rec_base.bs_versao < 500 )
      rec_base.bs_status = '4';
   else if ( rec_base.bs_versao < 600 )
      rec_base.bs_status = '5';
   else
      rec_base.bs_status = 0;
#else
   if ( rec_base.bs_versao < 500 )
      rec_base.bs_status = '4';
   else if ( rec_base.bs_versao < 600 )
      rec_base.bs_status = '5';
   else
      rec_base.bs_status = 0;
#endif

   if ( rec_base.bs_versao < 601 )
      rec_base.bs_versao = 601;




   /* regrava nova descricao atualizada */
	if ( WRTVREC(lb4_new, lb4_pos, (TEXT *)&rec_base, sizeof(Base)) != NO_ERROR) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion del header: [%d]\n", uerr_cod);
#else
      fprintf(stderr, "Erro na gravacao de header: [%d]\n", uerr_cod);
#endif
      cv_exit(50);
   }

   CLSFIL(lb4_new, COMPLETE);
   CLSFIL(lb4_old, COMPLETE);


   strcpy(backup, base);
   strcat(backup, ".cv");

   if ( access(backup, 0) == 0 ) {
      DELFILE(backup);
   }

   if ( RENFILE(arquivo, backup) == NO_ERROR ) {
      RENFILE(novo_arquivo, arquivo);
      novo_arquivo[0] = '\0';
   }
   else
      cv_exit(98);


   return(0);
}

COUNT analiza_velho()
{  COUNT ret, ordem, status, tpreg, sai;
   UCOUNT tamanho, livre;
   POINTER pos, proximo, lost;


   sai   = 0;
   indvis = indrel = 0;

   pos   = (POINTER)0;
   lost  = (POINTER)0;


#ifdef ESPANHA
   printf("Procesando registros de la base. Espere...\n");
#else
   printf("Processando registros da base. Aguarde...\n");
#endif

   while ( ! sai ) {

      ret = REG_INFO(lb4_old, pos, &tamanho, &livre, &proximo, &status);

      if ( depura )
         fprintf(stderr, "Ret= %2.2d  Pos = %7.7ld  Tam %7.7u  Livre %7.7u  Prox: %7.7ld  St: %c\n",
                          ret, pos, tamanho, livre, proximo, status);

      if ( pos == (POINTER) 0 && proximo != (POINTER)0 )
         goto cont;

      switch ( ret ) {
         case  READ_ERR :  /* Read erro */
#ifdef ESPANHA
                           fprintf(stderr, "Error de lectura en la descripcion de la base");
#else
                           fprintf(stderr, "Erro de leitura na descricao da base");
#endif
                           sai = 1;
                           break;

         case  LEOF_ERR :  /* fim de arquivo */
#ifdef ESPANHA
                           fprintf(stderr, "Fin del fichero de descripcion de la base");
#else
                           fprintf(stderr, "Fim do arquivo de descricao da base");
#endif
                           sai = 1;
                           break;

         case  RVHD_ERR :  /* marca de registro variavel invalido */
#ifdef ESPANHA
                           fprintf(stderr, "Posible perdida de informaciones");
#else
                           fprintf(stderr, "Possivel perda de informacoes");
#endif
                           lost += tamanho;
                           break;

         case  NO_ERROR :  /* registro OK */

                           if ( tamanho == 0 ) {
                              break;
                           }

                           ret = REG_READ(lb4_old, pos, tamanho, buf_iotxt);

                           if ( ret != NO_ERROR ) {
                              sai = 1;
                              break;
                           }

                           tpreg = ident_reg( buf_iotxt, tamanho, &ordem);
                           if ( tpreg != 0 ) {
                              switch(tpreg) {
                                 case 'C' :  pos_campos = pos; break;
                                 case 'S' :  pos_stp = pos;    break;
                                 case 'B' :  pos_hdr = pos;
                                             memcpy((TEXT *) &rec_base, buf_iotxt, sizeof(rec_base));
                                             release = rec_base.bs_versao;

                                             break;
                                 case 'V' :  pos_vistas = pos;
                                             break;
                                 case 'R' :  pos_relats = pos;
                                             break;
                                 case 'I' :  indvis++;
                                             if (indvis > MAX_VISTAS ) {
#ifdef ESPANHA
                                                fprintf(stderr, "Numero de la vista > que %d\n", MAX_VISTAS);
#else
                                                fprintf(stderr, "Numero da vista > que %d\n", MAX_VISTAS);
#endif
                                                indvis=MAX_VISTAS;
                                             }
                                             pos_ivis[indvis] = pos;
                                             break;
                                 case 'L' :  indrel++;
                                             if (indrel > MAX_VISTAS ) {
#ifdef ESPANHA
                                                fprintf(stderr, "Numero del listado > que %d\n", MAX_VISTAS);
#else
                                                fprintf(stderr, "Numero do relatorio > que %d\n", MAX_VISTAS);
#endif
                                                indrel=MAX_VISTAS;
                                             }
                                             pos_irel[indrel] = pos;
                                             break;


                              }

                           }

                           break;

#ifdef ESPANHA
         default        : fprintf(stderr, "Informacion no reconocida en la descripcion de la base ret = %d\n", ret);
#else
         default        : fprintf(stderr, "Informacao nao reconhecida na descricao da base ret = %d\n", ret);
#endif

      }

cont:

      if ( proximo == (POINTER) 0 ) sai = 1;
      else                pos = proximo;

   }

   ret = 0;

fim :

   return(ret);
}


COUNT ident_reg( buf, tam, ordem)
TEXT *buf;
UCOUNT tam;
COUNT *ordem;
{  COUNT ret, n=0;
   Hdr_bloco *hdr;

#ifdef PA800R
   n = 3; /* Alinha estrutura */
#endif

   *ordem = 0;
   ret = 0;

   /* Stop Words tem numero de registro 0000 */
   if ( (UTEXT)buf[0] == MARCA_TEXTO) { /* stop words */
      ret = SW;
      goto fim;
   }


   if ( tam == sizeof(Base)) {
      Base *pb;
      pb = (Base *)buf;
      if ( pb->bs_marca[0] == 'B' && pb->bs_marca[1] == 'S') {
         ret = 'B';
         goto fim;
      }
   }

   hdr = (Hdr_bloco *)buf;

   if ( hdr->marca_fim[0] == 0x6 && hdr->marca_fim[1] == 0x4 ) {
      ret = hdr->tipo;
      *ordem = hdr->ident;
      goto fim;
   }
   else {
#ifdef ESPANHA
      fprintf(stderr, "Item de descripcion de base desconocido[%c]\n", hdr->tipo);
#else
      fprintf(stderr, "Item de descricao de base desconhecido[%c]\n", hdr->tipo);
#endif
      ret = 0;
   }


fim :

   return ( ret );
}


VOID cria_novo(nx)
TEXT *nx;
{  POINTER pos;
   COUNT varl = VIRTUAL | EXCLUSIVE | VLENGTH;

   unlink(nx);

   if ( CREDAT(lb4_new, nx, 0, SLOT, varl, num_serie, id_arq ) != NO_ERROR ) {
#ifdef ESPANHA
      fprintf(stderr, "Error al abrir nuevo fichero\n");
#else
      fprintf(stderr, "Nao consegui abrir novo arquivo\n");
#endif
      cv_exit(7);
   }

   CLSFIL(lb4_new, COMPLETE);

   if ( OPNFIL(lb4_new, nx, VIRTUAL | EXCLUSIVE, num_serie, id_arq) != 0 ) {
#ifdef ESPANHA
      fprintf(stderr, "Error al abrir nuevo fichero\n");
#else
      fprintf(stderr, "Nao consegui abrir novo arquivo\n");
#endif
      cv_exit(4);
   }

   /* gravacao do header da base */
   if ( (pos = NEWVREC(lb4_new, sizeof(Base))) != (POINTER)0 ) {
      lb4_pos = pos;

	   if ( WRTVREC(lb4_new, pos, (TEXT *) &rec_base, sizeof(Base)) != NO_ERROR) {
#ifdef ESPANHA
         fprintf(stderr, "Error en la grabacion del header: [%d]\n", uerr_cod);
#else
         fprintf(stderr, "Erro na gravacao de header: [%d]\n", uerr_cod);
#endif
         cv_exit(5);
      }
   }
   else {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion del header: [%d]\n", uerr_cod);
#else
      fprintf(stderr, "Erro na gravacao de header: [%d]\n", uerr_cod);
#endif
      cv_exit(6);
   }
}


COUNT trata_conteudo()
{  COUNT ret=0, dif;
   COUNT tam_usar;

   recupera_campos();

   consiste_vistas();

   consiste_relats();


   tam_usar = GTVLEN(lb4_old, pos_stp);

   if ( RDVREC(lb4_old, pos_stp, buf_iotxt, tam_usar) != NO_ERROR ) {
      pos_stp = 0L;
   }
   else {
#ifdef FORMA_ANTIGA
      if ( release < 500 ) {
         dif = sizeof(struct hdtxt) - 6;
         pos_stp = NEWVREC(lb4_new, tam_usar + dif);

         w_memmove(buf_iotxt + dif, buf_iotxt, tam_usar );
         p_hdtxt = (struct hdtxt *)buf_iotxt;

         p_hdtxt->txt_marca   = MARCA_TEXTO;
         p_hdtxt->txt_record  = 0L;
         p_hdtxt->txt_campo   = 0;
         p_hdtxt->txt_parte   = 1;
         p_hdtxt->txt_proximo = (POINTER) 0L;

         WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar + dif);
      }
      else {
         pos_stp = NEWVREC(lb4_new, tam_usar);
	      WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar);
      }
#else
      p_hdtxt = (struct hdtxt *)buf_iotxt;
      if (  p_hdtxt->txt_marca   == MARCA_TEXTO &&
      		p_hdtxt->txt_record  == 0L &&
      		p_hdtxt->txt_campo   == 0 &&
      		p_hdtxt->txt_parte   == 1 &&
      		p_hdtxt->txt_proximo == (POINTER) 0L)  {
      	pos_stp = NEWVREC(lb4_new, tam_usar);
    		WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar);
    	}
    	else {
         dif = sizeof(struct hdtxt) - 6;
         pos_stp = NEWVREC(lb4_new, tam_usar + dif);

         w_memmove(buf_iotxt + dif, buf_iotxt, tam_usar );
         p_hdtxt = (struct hdtxt *)buf_iotxt;

         p_hdtxt->txt_marca   = MARCA_TEXTO;
         p_hdtxt->txt_record  = 0L;
         p_hdtxt->txt_campo   = 0;
         p_hdtxt->txt_parte   = 1;
         p_hdtxt->txt_proximo = (POINTER) 0L;

         WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar + dif);
    	}
#endif
   }


   WBS->bs_swpos = pos_stp;


   return(ret);
}

COUNT recupera_campos( )
{  COUNT ret, maior, i;
   UCOUNT tam;
   POINTER 	pos;
   Campo *pc;

   if ( pos_campos == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "No existe vector de campos\n");
#else
      fprintf(stderr, "Nao existe vetor de campos\n");
#endif
      cv_exit(60);
   }

   WBS->bs_cppos = pos_campos;

   /* load em modo edicao para permitir operacoes */
   v_campos[BASE_EDIT] = NULL;

   if ( (v_campos[BASE_EDIT] = load_campos(BASE_EDIT, 'E')) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la carga de los campos\n");
#else
      fprintf(stderr, "Erro na carga dos campos\n");
#endif
      cv_exit(61);
   }


   if ( (ret = qtd_vetcmp(BASE_EDIT)) == 0 ) {
#ifdef ESPANHA
      fprintf(stderr, "No existen campos\n");
#else
      fprintf(stderr, "Nao existem campos\n");
#endif
      cv_exit(62);
   }


#ifdef ESPANHA
   printf("\nCAMPOS RECUPERADOS :\n");
#else
   printf("\nCAMPOS RECUPERADOS :\n");
#endif

   for ( maior = i = 0 ; i < qtd_vetcmp(BASE_EDIT) ; i++ ) {

      if ( i % 3 == 0 )
         printf("\n   ");

      pc = pos_vetcmp(BASE_EDIT)[i];

      printf("[%3.3d] %-15.15s ", pc->cp_num, pc->cp_nome);

      if ( mapeia_cv ) {
         mapa_cv[pc->cp_num] = i+1;
         pc->cp_num = i+1;
      }
      maior = MAX(maior, pc->cp_num);
   }

   printf("\n\n");

   WBS->bs_u_seq = maior;
   WBS->bs_updated = 1;


   /* marca alteracao no vetor para salvar */
   v_campos[BASE_EDIT]->vi_status  |= VET_ALT;

   /* salva vetor de campos */

   tam = v_campos[BASE_EDIT]->vi_mtam + TAMANHO_HDR;

   if ( (pos = NEWVREC(lb4_new, tam)) == (POINTER)0 ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion del nuevo fichero!!\n");
#else
      fprintf(stderr, "Erro na gravacao do novo arquivo!!\n");
#endif
      cv_exit(10);
   }

   if ( pos != (POINTER) 0 ) {
      if ( save_vet(v_campos[BASE_EDIT], pos) != (POINTER) NULL ) {
         WBS->bs_cppos = pos;
         WBS->bs_u_seq = maior;
         WBS->bs_status = 0;
         WBS->bs_updated = 1;
      }
   }

   if ( v_campos[BASE_EDIT] != NULL ) {
      rlse_campos(BASE_EDIT);
      v_campos[BASE_EDIT] = NULL;
   }

   return(ret);
}


COUNT consiste_vistas()
{  COUNT ret = -1, i, new_ordem, ind, x, respeita;
   POINTER 	pos;
   Vista    **vet_vis, *pv;
   Vet_itens *vv_old, *vv;
   Vet_itens *vi;


   new_ordem = 1;
   WBS->bs_vspos = pos_vistas;

   /* load em modo edicao para permitir operacoes */
   vv_old = vv = NULL;

   /* vetor antigo */
   if ( (vv_old = load_vistas(BASE_EDIT, 'E')) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la carga de las vistas. ===== Voy a crear ====\n");
#else
      fprintf(stderr, "Erro na carga das vistas. ===== Vou recriar ====\n");
#endif
      WBS->bs_vspos = 0L;
      vv_old = load_vistas(BASE_EDIT, 'E');
   }

   /* vetor novo */
   WBS->bs_vspos = 0L;
   vv = load_vistas(BASE_EDIT, 'E');


   vet_vis = (Vista **) vv_old->vi_vtit;  /* aponta para vetor de vistas */

   if ( vv_old->vi_nelem == WBS->bs_n_vis )
      respeita = 1;
   else
      respeita = 0;


   for ( i = 1 ; i <= MAX_VISTAS; i++ ) {

      pv = vet_vis[i-1];
      ind = i;



      if ( pv != NULL && i <= vv_old->vi_nelem) {
         ap_vista = *pv;


         for ( x = 1; x <= MAX_VISTAS; x++) {
            if ( pos_ivis[x] == pv->vis_itpos ) {
               ind = x;
               break;
            }
         }
      }
      else {
         if ( respeita )
            continue;
         else {
#ifdef ESPANHA
            strcpy(ap_vista.vis_ident, "Sin nombre");
#else
            strcpy(ap_vista.vis_ident, "Sem nome");
#endif
            strcpy(ap_vista.vis_dfacess, "");
            pv = &ap_vista;
         }
      }

      /* tem itens localizados */
      if ( pos_ivis[ind] != 0L) {
         pv->vis_itpos = pos_ivis[ind];
         if ( (vi = load_itvis(pv, 'E')) == NULL ) {
#ifdef ESPANHA
            printf("Vista [%s] Descartada. No ha cargado elementos de la vista %d\n",
#else
            printf("Vista [%s] Descartada. Nao corregou itens da vista %d\n",
#endif
               ap_vista.vis_ident, i+1);
            continue;
         }

      }
      else {
#ifdef ESPANHA
         printf("Vista [%s] Descartada. Sin elementos en la vista %d\n",
#else
         printf("Vista [%s] Descartada. Sem itens na vista %d\n",
#endif
            ap_vista.vis_ident, i+1);


         continue;
      }


      if ( mapeia_cv )
         vs_cvcampo(vi);

      vi->vi_ident = new_ordem;

      if ( (pos = salva_itens(vi)) == NULL ) {
#ifdef ESPANHA
         printf("Vista [%s] Descartada. No consegui salvar elementos de la vista %d\n",
#else
         printf("Vista [%s] Descartada. Nao conseguiu salvar itens da vista %d\n",
#endif
            ap_vista.vis_ident, i+1);
         continue;
      }

      rlse_vet(vi);

      ap_vista.vis_ordem = new_ordem;
      ap_vista.vis_it_ativo  = -1;
      ap_vista.vis_old_ativo = -1;
      ap_vista.vis_vet = NULL;
      ap_vista.vis_itpos = pos;

      vv->vi_ident++;

      if ( add_item(vv, new_ordem, &ap_vista, sizeof(Vista), 0) == NULL ) {
#ifdef ESPANHA
         printf("Vista [%s] Descartada. Error en la inclusion de vista\n", ap_vista.vis_ident);
#else
         printf("Vista [%s] Descartada. Erro na inclusao de vista\n", ap_vista.vis_ident);
#endif
         continue;
      }

      new_ordem++;

#ifdef ESPANHA
      printf("Vista [%s] recuperada Ok\n", ap_vista.vis_ident);
#else
      printf("Vista [%s] recuperada Ok\n", ap_vista.vis_ident);
#endif
   }


   if ( (pos = salva_itens(vv)) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion de las vistas. Ninguna vista recuperada\n");
#else
      fprintf(stderr, "Erro na gravacao das vistas. Nenhuma vista recuperada\n");
#endif
   }
   else {
      WBS->bs_n_vis = new_ordem - 1;
      WBS->bs_vspos = pos;
   }

fim :

   if ( vv_old != NULL ) {
      rlse_vet(vv_old);
   }

   if ( vv != NULL ) {
      rlse_vet(vv);
   }

   printf("\n");

   return(ret);
}


COUNT consiste_relats()
{  COUNT ret = -1, i, new_ordem, ind, x, respeita;
   POINTER 	pos;
   Rel      **vet_rel, *pr;
   Vet_itens *vv_old, *vv;
   Vet_itens *vi;


   new_ordem = 1;
   WBS->bs_rlpos = pos_relats;

   /* load em modo edicao para permitir operacoes */
   vv_old = vv = NULL;

   /* vetor antigo */
   if ( (vv_old = load_rels(BASE_EDIT, 'E')) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la carga del listado ===== Voy a crear ====\n");
#else
      fprintf(stderr, "Erro na carga das relats. ===== Vou recriar ====\n");
#endif
      WBS->bs_rlpos = 0L;
      vv_old = load_rels(BASE_EDIT, 'E');
   }

   /* vetor novo */
   WBS->bs_rlpos = 0L;
   vv = load_rels(BASE_EDIT, 'E');


   vet_rel = (Rel **) vv_old->vi_vtit;  /* aponta para vetor de relats */

   if ( vv_old->vi_nelem == WBS->bs_n_rel )
      respeita = 1;
   else
      respeita = 0;


   for ( i = 1 ; i <= MAX_VISTAS; i++ ) {

      pr = vet_rel[i-1];
      ind = i;

      if ( pr != NULL && i <= vv_old->vi_nelem) {
         ap_rel = *pr;
         for ( x = 1; x <= MAX_VISTAS; x++) {
            if ( pos_irel[x] == pr->rel_itpos ) {
               ind = x;
               break;
            }
         }
      }
      else {
         if ( respeita )
            continue;
         else {
#ifdef ESPANHA
            strcpy(ap_rel.rel_ident,  "Sin nombre");
            strcpy(ap_rel.rel_titulo, "Titulo");
            strcpy(ap_rel.rel_rodape, "Pie de pagina");
#else
            strcpy(ap_rel.rel_ident,  "Sem nome");
            strcpy(ap_rel.rel_titulo, "Titulo");
            strcpy(ap_rel.rel_rodape, "Rodape");
#endif
            ap_rel.rel_n_elem = 66;
            ap_rel.rel_tipo   = 'F';
            ap_rel.rel_linhas = 66 ;
            ap_rel.rel_colunas = 132;
            ap_rel.rel_n_etq = 66;

            strcpy(ap_rel.rel_dfacess, "");
            ap_rel.rel_itpos = 0L;
            pr = &ap_rel;
         }
      }

      /* tem itens localizados */
      if ( pos_irel[ind] != 0L) {
         pr->rel_itpos = pos_irel[ind];
         if ( (vi = load_itrel(pr, 'E')) == NULL ) {
#ifdef ESPANHA
            printf("Rel. [%s] Descartado. No cargo elementos del listado %d\n",
#else
            printf("Rel. [%s] Descartado. Nao corregou itens do relat %d\n",
#endif
               ap_rel.rel_ident, i+1);
            continue;
         }
      }
      else {
#ifdef ESPANHA
         printf("Rel. [%s] Descartado. Sin elementos en el listado %d\n",
#else
         printf("Rel. [%s] Descartado. Sem itens no relatorio %d\n",
#endif
            ap_rel.rel_ident, i+1);
         continue;
      }


      if ( mapeia_cv )
         rl_cvcampo(vi);

      vi->vi_ident = new_ordem;

      if ( (pos = salva_itens(vi)) == NULL ) {
#ifdef ESPANHA
         printf("Rel. [%s] Descartado. No consiguio salvar elementos del listado %d\n",
#else
         printf("Rel. [%s] Descartado. Nao conseguiu salvar itens do relat. %d\n",
#endif
            ap_rel.rel_ident, i+1);
         continue;
      }

      rlse_vet(vi);

      ap_rel.rel_ordem = new_ordem;
      ap_rel.rel_it_ativo  = -1;
      ap_rel.rel_old_ativo = -1;
      ap_rel.rel_vet = NULL;
      ap_rel.rel_itpos = pos;

      vv->vi_ident++;

      if ( add_item(vv, new_ordem, &ap_rel, sizeof(Rel), 0) == NULL ) {
#ifdef ESPANHA
         printf("Listado [%s] Descartado. Error en la inclusion del listado\n", ap_rel.rel_ident);
#else
         printf("Rel. [%s] Descartado. Erro na inclusao de Relatorio\n", ap_rel.rel_ident);
#endif
         continue;
      }

      new_ordem++;

#ifdef ESPANHA
      printf("Listado [%s] Recuperado Ok.\n", ap_rel.rel_ident);
#else
      printf("Rel. [%s] Recuperado Ok.\n", ap_rel.rel_ident);
#endif
   }

   if ( (pos = salva_itens(vv)) == NULL ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion de los listados. Ningun listado recuperado.\n");
#else
      fprintf(stderr, "Erro na gravacao das relats. Nenhum Relat recuperado\n");
#endif
   }
   else {
      WBS->bs_n_rel = new_ordem - 1;
      WBS->bs_rlpos = pos;
   }

fim :

   if ( vv_old != NULL ) {
      rlse_vet(vv_old);
   }

   if ( vv != NULL ) {
      rlse_vet(vv);
   }

   printf("\n");

   return(ret);
}



POINTER salva_itens(vi)
Vet_itens *vi;
{  COUNT tam;
   POINTER pos, pos_ret;

   pos_ret = NULL;

   tam = vi->vi_mtam + TAMANHO_HDR + ap_extravet;

   if ( (pos = NEWVREC(lb4_new, tam)) == (POINTER)0 ) {
#ifdef ESPANHA
      fprintf(stderr, "Error en la grabacion del nuevo fichero.\n");
#else
      fprintf(stderr, "Erro na gravacao do novo arquivo.\n");
#endif
      cv_exit(10);
   }

   if ( pos != (POINTER) 0 ) {
      vi->vi_status  |= VET_ALT;
      if ( save_vet(vi, pos) != (POINTER) NULL ) {
         pos_ret = pos;
      }
   }

   return(pos_ret);
}



VOID vs_cvcampo(vi)
Vet_itens *vi;
{  COUNT i;
   TTela *pe;


   for ( i = 0 ; i < vi->vi_nelem ; i++ ) {

      pe = (TTela *)vi->vi_vtit[i];


      if ( pe->te_tipo == CAMPO_G || pe->te_tipo == CAMPO_E || pe->te_tipo == CAMPO_S ) {

         if ( pe->te_num <= 0 )
            fprintf(stderr, "     Tela %d   linha %d  coluna %d\n", pe->te_tela, pe->te_linha, pe->te_coluna);
         if ( mapeia_cv && pe->te_num >= 0 ) {
            pe->te_num = mapa_cv[pe->te_num];
         }
      }
   }

}


VOID rl_cvcampo(vi)
Vet_itens *vi;
{  COUNT i;
   RTela *pe;


   for ( i = 0 ; i < vi->vi_nelem ; i++ ) {

      pe = (RTela *)vi->vi_vtit[i];


      if ( pe->re_tipo == CAMPO_G || pe->re_tipo == CAMPO_E || pe->re_tipo == CAMPO_S ) {

         if ( pe->re_num <= 0 )
            fprintf(stderr, "     Tela %d   linha %d  coluna %d\n", pe->re_tela, pe->re_linha, pe->re_coluna);
         if ( mapeia_cv && pe->re_num >= 0) {
            pe->re_num = mapa_cv[pe->re_num];
         }
      }
   }

}

/*======================================================================
========================================================================
                            lb2but.c
========================================================================
=======================================================================*/


/*---------------------------------------------------------------------*/
/*   C A M P O S                                                       */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_campos(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max, nelem, i;
   UCOUNT qtd_max;
   Campo **vetcmp, *pc;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_CAMPOS;
      qtd_max = sizeof(Campo) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Campo) * (el_max + 1);
   }

   v = load_vet('C', 0, modo, v_bases[sele]->bs_cppos, el_max, qtd_max);

   if ( v != NULL ) {
      vetcmp = (Campo **)v->vi_vtit;
      nelem  = v->vi_nelem;
      for ( i = 0; i < nelem; i++) {
         pc = vetcmp[i];
         pc->cp_olddata = NULL;
         pc->cp_newdata = NULL;
         pc->cp_oldtam  = 0;
         pc->cp_newtam  = 0;
         pc->cp_adoc    = NULL;
         pc->cp_pttab   = NULL;
      }
   }

   return(v);
}

F__GLB   VOID rlse_campos(sele)
COUNT sele;
{
   if ( v_campos[sele] != NULL ) {
      rlse_vet(v_campos[sele]);
      v_campos[sele] = NULL;
   }
}


F__GLB   Campo **pos_vetcmp(sele)
COUNT sele;
{

   if ( v_campos[sele] != NULL )
      return((Campo **)v_campos[sele]->vi_vtit);
   else
      return((Campo **)NULL);
}


F__GLB   COUNT qtd_vetcmp(sele)
COUNT sele;
{
   if ( v_campos[sele] != NULL )
      return(v_campos[sele]->vi_nelem);
   else
      return(0);
}


F__GLB   COUNT acha_campo( sele, num )
COUNT sele, num;
{  COUNT  ret, i;
   Campo **campos;

   campos = pos_vetcmp(sele);

   ret = -1;

   for( i = 0;  i  <  qtd_vetcmp(sele);  i++ ) {
      if ( campos[i]->cp_num  ==  num ) {
         ret = i;
         break;
      }
   }

   return ( ret );
}


/*---------------------------------------------------------------------*/
/*   V I S T A S                                                       */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_vistas(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_VISTAS;
      qtd_max = sizeof(Vista) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Vista) * (el_max + 1);
   }

   v = load_vet('V', 0, modo, v_bases[sele]->bs_vspos, el_max, qtd_max);

   return(v);
}




F__GLB   Vet_itens *load_itvis(vista, flag)
Vista *vista;
COUNT flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = ap_mxelem;
      qtd_max = ap_sizeio;   /* sizeof(TTela) * el_max; nao pode por ter final variavel */
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(TTela) * (el_max + 1);
   }

   v = load_vet('I', 0, modo, vista->vis_itpos, el_max, qtd_max);


   if ( ap_extravet > 0 ) {
      debug("Extra vet");
/*      ap_visdoc = load_buffer( 0, ET_MEM, (TEXT *) buf_iotxt, (LONG)ap_extravet); */
   }

   ap_extravet = 0;

   return(v);
}



F__GLB   TTela *pos_itvis(num)
COUNT num;
{

   if ( ap_vista.vis_vet->vi_vtit  != NULL )
      return((TTela *)ap_vista.vis_vet->vi_vtit[num]);
   else
      return((TTela*)NULL);
}

F__GLB   COUNT qtd_itvis()
{
   if ( ap_vista.vis_vet->vi_vtit  != NULL )
      return(ap_vista.vis_vet->vi_nelem);
   else
      return(0);
}




/*---------------------------------------------------------------------*/
/*   R E L A T O R I O S                                               */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_rels(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_REL;
      qtd_max = sizeof(Rel) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Rel) * (el_max + 1);
   }

   v = load_vet('R', 0, modo, v_bases[sele]->bs_rlpos, el_max, qtd_max);

   return(v);
}




F__GLB   Vet_itens *load_itrel(rel, flag)
Rel *rel;
COUNT flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = ap_mxelem;
      qtd_max = ap_sizeio;   /* sizeof(RTela) * el_max; nao pode por ter final variavel */
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(RTela) * (el_max + 1);
   }

   v = load_vet('L', 0, modo, rel->rel_itpos, el_max, qtd_max);

   return(v);
}



F__GLB   RTela *pos_itrel(num)
COUNT num;
{

   if ( ap_rel.rel_vet->vi_vtit  != NULL )
      return((RTela *)ap_rel.rel_vet->vi_vtit[num]);
   else
      return((RTela*)NULL);
}

F__GLB   COUNT qtd_itrel()
{
   if ( ap_rel.rel_vet->vi_vtit  != NULL )
      return(ap_rel.rel_vet->vi_nelem);
   else
      return(0);
}



/*======================================================================
========================================================================
                            lb2vetdf.c
========================================================================
=======================================================================*/

#ifdef MSDOS
   VOID v_shfrgt(UTEXT *base, UCOUNT tam_buf, UCOUNT ref, UCOUNT qtd);
   VOID v_shflft(UTEXT *base, UCOUNT tam_buf, UCOUNT ref, UCOUNT qtd);
#else
   VOID v_shfrgt( );
   VOID v_shflft( );
#endif

/*#  ---------------------------------------------------------------------
**#   Funcao...: save_vet
**#   Objetivo.: Salvar em disco um bloco de elementos
**#   Entrada..: Parametros Abaixo
**#   Retorna..: Posicao do aquivo onde foi gravada ou NULL se Erro
**#
**#      onde : fd_arq   ->  file_descriptor do arquivo
**#      onde : file_pos ->  Posicao do disco onde devera ser gravada
**/

F__GLB   POINTER save_vet(vti, file_pos)
Vet_itens *vti;
POINTER file_pos;
{  COUNT ret;
   UCOUNT tam_usar = 0;
   Hdr_bloco hdr;
   TEXT *buf_le;
   TEXT *base;

   ret = 0;
   buf_le = buf_iotxt;


   if ( (vti->vi_status & VET_EDIT) == 0 ) {
      debug("Nao pode gravar sem ter sido chamado para edicao");
      ret = -1;
      goto fim;
   }

   if ( (vti->vi_status & (~VET_EDIT)) == 0 ) {
      debug("Nada foi alterado. Gravacao NAO efetuada");
      ret = -1;
      goto fim;
   }


   hdr.tipo  = vti->vi_tipo;
   hdr.ident = vti->vi_ident;
   hdr.tamanho = vti->vi_mtam;
   hdr.num_elementos = vti->vi_nelem;
   hdr.marca_fim[0] = 0x06;
   hdr.marca_fim[1] = 0x04;

   base            = vti->vi_buffer - TAMANHO_HDR;
   vti->vi_ftam    = hdr.tamanho + TAMANHO_HDR;
   vti->vi_pos     = file_pos;

   memcpy(base, &hdr, TAMANHO_HDR);
   tam_usar = vti->vi_ftam;

   if ( ap_extravet > 0 ) {
      tam_usar += ap_extravet;
      if ( tam_usar > ap_sizeio ) {
         if ( (buf_le = malloc(tam_usar+10)) == NULL ) { /* 10 e folga */
            ret = -3; /* Sem memoria */
            goto fim;
         }
      }

      w_memmove(buf_le + vti->vi_ftam, buf_iotxt, ap_extravet);
      memcpy(buf_le, base, vti->vi_ftam);
      base = buf_le;
   }


	if ( WRTVREC(lb4_new, vti->vi_pos, base, tam_usar) != 0 ) {
      ret = -1; /* erro na gravacao do header */
      goto fim;
   }

   vti->vi_status  = ( vti->vi_status & VET_EDIT ) ? VET_EDIT : 0;

fim :

   if ( ret < 0 ) {
      file_pos = NULL;
   }

   if ( buf_le != buf_iotxt && buf_le != NULL )
      free(buf_le);

   return(file_pos);
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: add_item
**#   Objetivo.: Incluir um item no vetor
**#   Entrada..: Parametros Abaixo
**#   Retorna..: Ponteiro para area onde item foi colocado ou NULL se Erro
**#
**#      onde : vti        -> Endereco da estrutura de controle
**#      onde : pos        -> posicao que devera ocupar (Indice em vi_vtit)
**#      onde : item       -> Ponteiro para dados do item (Informacao)
**#      onde : tam_item   -> Tamanho do item
**#      onde : shift_flag -> Indicacao se devera ser efetuado shift nos
**#                           ponteiros de vi_vtit. Explicacao : Funcao de
**#                           manipular tabelas ja executa shift no vetor
**#                           de ponteiros portanto para nao haver duplo
**#                           shift, Incluimos esta flag.
**/
F__GLB   VOID *add_item(vti, pos, item, tam_item, shift_flag)
Vet_itens *vti;
COUNT pos;
VOID *item;
UCOUNT tam_item;
COUNT shift_flag;
{  VOID *p_ret;
   LONG tam_long;
   UTEXT *p;
   COUNT offset, i;
   UCOUNT tam;

   p_ret = NULL;

   if ( (vti->vi_status & VET_EDIT) == 0 ) {
      debug("Nao pode Incluir sem ter sido chamado para edicao");
      goto fim;
   }


   if ( vti == NULL ||  pos < 0  )
      goto fim;

   /* se pos maior que ultimo inclui no final */
   pos = MIN(pos, vti->vi_nelem);

   /* Verifica se pode incluir. Maximo de elementos atingido */
   if ( vti->vi_nelem >= vti->vi_nmax )
      goto fim;

   /* Verifica se pode incluir. Maximo de memoria disponivel atingido */
   if ( vti->vi_mtam + TAM_ITEM(tam_item) + TAM_TAM > vti->vi_mmax )
      goto fim;

   /* se nao for a ultima posicao, abre espaco em buffer */
   if ( pos == vti->vi_nelem ) {
      p = (UTEXT *)vti->vi_buffer + vti->vi_mtam;
   }
   else {
      if ( ! shift_flag ) {
         /* quando e chamada por tabela o indice vem apontando para buffer de edicao */
         if ( pos == 0 ) {
            p = (UTEXT *)vti->vi_buffer + TAM_TAM;
         }
         else {
            p = (UTEXT *)vti->vi_vtit[pos-1];
            tam = (COUNT)GET_LONG((p-TAM_TAM));
            p += (TAM_ITEM(tam) + TAM_TAM );
         }
      }
      else {
         p = (UTEXT *)vti->vi_vtit[pos];
      }
      p -= TAM_TAM;   /* faz apontar para tamanho do item corrente */
      offset = p - (UTEXT *)vti->vi_buffer;
      v_shfrgt((UTEXT*)vti->vi_buffer, vti->vi_mtam, offset,
           TAM_ITEM(tam_item) + TAM_TAM);
   }

   /* coloca item no buffer */
   tam_long = TAM_ITEM(tam_item);
   PUT_LONG(p, tam_long);
   p += TAM_TAM;

   if ( item != NULL )
      memcpy(p, item, TAM_ITEM(tam_item));
   else
      memset(p, 0, TAM_ITEM(tam_item));



   /* coloca item no vetor de ponteiros */
   if ( pos < vti->vi_nelem ) {
      if ( shift_flag )
         for ( i = vti->vi_nelem; i > pos; i-- )
            vti->vi_vtit[i] = vti->vi_vtit[i-1];

      for ( i = vti->vi_nelem; i > pos; i-- ) {
         COUNT x;
         x = TAM_ITEM(tam_item) + TAM_TAM;
         vti->vi_vtit[i] = vti->vi_vtit[i] + x;
      }
   }

   vti->vi_vtit[pos] = (TEXT *)p;

   if ( shift_flag ) /* para nao melar buffer de edicao de tabela */
      vti->vi_vtit[vti->vi_nelem+1] = NULL;

   vti->vi_mtam += (TAM_ITEM(tam_item) + TAM_TAM );
   vti->vi_nelem++;
   vti->vi_curr  = pos;
   vti->vi_clen  = TAM_ITEM(tam_item);

   vti->vi_status  |= VET_INC;  /* marca inclusao no vetor */

   p_ret = p;

fim :

   return(p_ret);
}


/*#  ---------------------------------------------------------------------
**#   Funcao...: del_item
**#   Objetivo.: Deleta item corrente do vetor
**#   Entrada..: Parametros Abaixo
**#   Retorna..: 0 se exclui OK
**#              -1 se  NAO  excluiu
**#
**#      onde : vti        -> Endereco da estrutura de controle
**#      onde : shift_flag -> Indicacao se devera ser efetuado shift nos
**#                           ponteiros de vi_vtit. Explicacao : Funcao de
**#                           manipular tabelas ja executa shift no vetor
**#                           de ponteiros portanto para nao haver duplo
**#                           shift, Incluimos esta flag.
**/
F__GLB   COUNT del_item(vti, shift_flag)
Vet_itens *vti;
COUNT shift_flag;
{  COUNT ret, pos, tam_item;
   UTEXT *p;
   COUNT offset, i;

   ret = -1;

   if ( (vti->vi_status & VET_EDIT) == 0 ) {
      debug("Nao pode Excluir sem ter sido chamado para edicao");
      goto fim;
   }


   if ( vti == NULL ||  vti->vi_nelem == 0  )
      goto fim;

   pos      = vti->vi_curr;
   tam_item = vti->vi_clen;

   /* se NAO for a ultima posicao, Fecha espaco em buffer */
   if ( pos != (vti->vi_nelem -1 )) {
      p = (UTEXT *)vti->vi_vtit[pos+1];
      p -= TAM_TAM;   /* faz apontar para inicio do proximo item */
      offset = p - (UTEXT *)vti->vi_buffer;
      v_shflft((UTEXT*)vti->vi_buffer, vti->vi_mtam, offset,
           TAM_ITEM(tam_item) + TAM_TAM);
   }


   /* retira item no vetor de ponteiros */
   if ( pos != (vti->vi_nelem -1 )) {
      if ( shift_flag )
         for ( i = pos; i < vti->vi_nelem; i++ )
            vti->vi_vtit[i] = vti->vi_vtit[i+1];

      for ( i = pos; i < vti->vi_nelem; i++ ) {
         COUNT x;
         x = TAM_ITEM(tam_item) + TAM_TAM;
         vti->vi_vtit[i] = vti->vi_vtit[i] - x;
      }
   }

   vti->vi_nelem--;
   if ( shift_flag ) /* para nao melar buffer de edicao de tabela */
      vti->vi_vtit[vti->vi_nelem] = NULL;

   vti->vi_mtam -= (TAM_ITEM(tam_item) + TAM_TAM );
   vti->vi_status  |= VET_DEL;  /* marca exclusao no vetor */


   vti->vi_curr  = MIN(pos, (vti->vi_nelem - 1));

   p = (UTEXT *)vti->vi_vtit[vti->vi_curr];

   if (p != NULL )
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   else
      vti->vi_clen = 0;

   ret = 0;

fim :

   return(ret);
}

/*#  ---------------------------------------------------------------------
**#   Funcao...: v_shfrgt
**#   Objetivo.: empura bytes para direita ( abre espaco )
**#
**/
F__LOC   VOID v_shfrgt(base, tam_buf, ref, qtd)
UTEXT *base;
UCOUNT tam_buf, ref, qtd;
{
	FAST UTEXT *dp, *sp;
   COUNT move;

   move = tam_buf - ref;

   sp = &base[tam_buf-1];
   dp = &base[tam_buf+qtd-1];

   while (move--)
		*dp-- = *sp--;
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: v_shflft
**#   Objetivo.: empura bytes para esquerda ( fecha espaco )
**#
**/
F__LOC   VOID v_shflft(base, tam_buf, ref, qtd)
UTEXT *base;
UCOUNT tam_buf, ref, qtd;
{
	FAST UTEXT *sp;

   sp = &base[ref];

	memcpy(&base[ref-qtd], sp, tam_buf - ref);
}


/*======================================================================
========================================================================
                            lb2vetut.c
========================================================================
=======================================================================*/

#ifdef MSDOS
   VOID converte_buf(TEXT *, TEXT *, COUNT);
#else
   VOID converte_buf( );
#endif



/*#  ---------------------------------------------------------------------
**#   Funcao...: load_vet
**#   Objetivo.: Carregar em memoria um bloco de elementos
**#   Entrada..: Parametros Abaixo
**#   Retorna..: Ponteiro para estrutura alocada ou NULL se Erro
**#
**#      onde : tipo -> 'C' - Campos
**#                  -> 'V' - Vistas
**#                  -> 'R' - Relatorio
**#                  -> 'I' - Itens de Vistas
**#                  -> 'E' - Itens de Relatorio
**#                  -> 'A' - Acessos
**#      onde : Ident-> Numero de identificacao do vetor
**#      onde : modo -> 'F' - Fixo. Nada pode ser alterado
**#                  -> 'E' - Itens podem ser modificados (edicao)
**#      onde : fd_arq   ->  file_descriptor do arquivo
**#      onde : file_pos ->  Posicao em disco do bloco com itens. Se NULL
**#                          inicaliza bloco.
**#      onde : tam_max  ->  Tamanho a ser alocado   em caso de edicao
**#      onde : max_elem ->  Maximo de elementos     em caso de edicao
**/

F__GLB   Vet_itens *load_vet(tipo, ident, modo, pos, max_elem, max_tam)
COUNT tipo, ident;
TEXT modo;
POINTER pos;
COUNT max_elem;
UCOUNT max_tam;
{  COUNT ret, tam, i, libera_buf;
   TEXT *buf_le;
   Vet_itens *vti;
   UCOUNT qtd_buf, qtd_ptr, tam_usar;
   Hdr_bloco hdr;
   TEXT *p1, *p2;
   UTEXT *p;

   ret = 0;
   p1 = p2 = NULL;
   vti = (Vet_itens *)NULL;
   ap_extravet = 0;

   buf_le = buf_iotxt;
   libera_buf = 0;   /* nao tem buffer alocado. so o faz se buf_iotxt for pequeno */

   memset(&hdr, '\0', sizeof(hdr));
   memset(buf_le, '\0', (UCOUNT)SIZE_IOTXT);


   /* primeiro verifica se em posicionamento tem header valido */

   if ( pos != 0L ) {
      tam_usar = GTVLEN(lb4_old, pos);
      if ( tam_usar > ap_sizeio ) {
         if ( (buf_le = malloc(tam_usar+10)) == NULL ) { /* 10 e folga */
            ret = -3; /* Sem memoria */
            goto fim;
         }
         libera_buf = 1;
      }


      if ( RDVREC(lb4_old, pos, buf_le, tam_usar) != NO_ERROR ) {
         ret = -1; /* nao tem header */
         goto fim;
      }

      memcpy(&hdr, buf_le, sizeof(hdr));

      /* verifica se em posicionamento tem bloco solicitado */
      if ( hdr.marca_fim[0] != 0x6 || hdr.marca_fim[1] != 0x4 ) {
         ret = -1; /* header invalido */
         goto fim;
      }
      if ( hdr.tipo != tipo || ( ident != 0 && hdr.ident != ident) ) {
         ret = -2; /* Bloco solicitado nao confere com posicionamento */
         goto fim;
      }

      ident = hdr.ident;
   }

   /* IDENTIFICA SE E VERSAO 1.5 */

   if (repro1_5 == 99 )
      repro1_5 = e_versao5(buf_le + TAMANHO_HDR);

   /* Calcula quantidade de memoria a ser alocada para o bloco */

   if ( modo == EDIT_OK )  {
      qtd_ptr = max_elem;
      qtd_buf = max_tam;
   }
   else {
      qtd_ptr = hdr.num_elementos;
      if ( repro1_5 )
         qtd_buf = hdr.tamanho + ( (TAM_TAM - 2) * hdr.num_elementos);
      else
         qtd_buf = hdr.tamanho;
   }


   /* aloca estrutura controle + area ponteiros + area info */
   if ( !(vti = (Vet_itens *) malloc(sizeof(Vet_itens)))) {
      ret = -3; /* Sem memoria */
      goto fim;
   }

   p1 = calloc(sizeof(TEXT *), qtd_ptr+1);
   p2 = malloc(qtd_buf + TAMANHO_HDR + 10 ); /* 10 e folga */

   if ( p1 == NULL || p2 == NULL ) {
      ret = -3; /* Sem memoria */
      goto fim;
   }


   /* Leitura do bloco propriamente dito */
   if ( lb4_old > 0  && pos != 0) {
      if ( repro1_5 )
         converte_buf(p2 + TAMANHO_HDR, buf_le + sizeof(hdr), qtd_ptr);
      else {
         memcpy(p2 + TAMANHO_HDR, buf_le + TAMANHO_HDR, hdr.tamanho);
         /* verifica se informacao extra no bloco. Atualiza em ap_extravet */
         /* se existir deixar a mesma em buf_iotxt */
         ap_extravet = tam_usar - hdr.tamanho - TAMANHO_HDR;
      }
   }
   else {
      hdr.tamanho = 0;
      hdr.num_elementos = 0;
   }

   vti->vi_tipo    = tipo;
   vti->vi_ident   = ident;
   vti->vi_status  = (modo == EDIT_OK) ? VET_EDIT : 0;

   vti->vi_pos     = pos;
   vti->vi_ftam    = TAMANHO_HDR + hdr.tamanho;

   vti->vi_mmax    = qtd_buf;
   vti->vi_nmax    = qtd_ptr;

   vti->vi_buffer  = p2 + TAMANHO_HDR;
   vti->vi_vtit    = (TEXT **)p1;

   vti->vi_mtam    = 0;
   vti->vi_nelem   = 0;
   vti->vi_curr    = 0;
   vti->vi_clen    = 0;

   /* monta vetor de ponteiros para informacoes */

   for ( i = 0, p = (UTEXT*) vti->vi_buffer; i < hdr.num_elementos; i++ ) {
      tam = (COUNT)GET_LONG(p);
      p += TAM_TAM;   /* faz apontar para tamanho do item corrente */

      tam = TAM_ITEM(tam);

      vti->vi_vtit[i] = (TEXT *)p;
      p += tam;

      vti->vi_mtam += (tam + TAM_TAM);
      vti->vi_nelem++;
   }


fim :

   if ( ret < 0 ) {
      if ( p2  != NULL ) free(p2);
      if ( p1  != NULL ) free(p1);
      if ( vti != NULL ) free(vti);
      vti = NULL;
   }
   else {
      if ( ap_extravet > 0 )  {
         p1 = buf_le + TAMANHO_HDR + hdr.tamanho;
         memcpy(buf_iotxt, p1, ap_extravet);
      }
   }

   if ( libera_buf ) free(buf_le);

   return(vti);
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: rlse_vet
**#   Objetivo.: Libera memoria utilizada por uma lista
**#
**/
F__GLB   VOID rlse_vet(vti)
Vet_itens *vti;
{  TEXT *p1;
   if ( vti != NULL ) {
      p1 = vti->vi_buffer;
      if ( p1 != NULL ) free(p1 - TAMANHO_HDR);
      if ( vti->vi_vtit   != NULL ) free(vti->vi_vtit);
      free(vti);
   }
}




/*#  ---------------------------------------------------------------------
**#   Funcao...: frs_item
**#   Objetivo.: Retorna endereco de memoria do primeiro item
**#
**/
F__GLB   VOID *fst_item(vti)
Vet_itens *vti;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || vti->vi_nelem < 1 ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr = 0;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}




/*#  ---------------------------------------------------------------------
**#   Funcao...: nxt_item
**#   Objetivo.: Retorna endereco de memoria do proximo item
**#
**/
F__GLB   VOID *nxt_item(vti)
Vet_itens *vti;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || (vti->vi_curr + 1) >= vti->vi_nelem  ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr++;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: pos_item
**#   Objetivo.: Retorna endereco de memoria do item mencionado
**#
**/
F__GLB   VOID *pos_item(vti, pos)
Vet_itens *vti;
COUNT pos;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || pos >= vti->vi_nelem || pos < 0  ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr = pos;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}







F__LOC VOID converte_buf(dest, orig, qtd)
TEXT *dest, *orig;
COUNT qtd;
{  COUNT i, tam;
   UTEXT *p;
   LONG tam_long;

   p = (UTEXT *)orig;

   for ( i = 0; i <= qtd; i++ ) {
      tam = (*p++) * 256;
      tam += *p++;

      if ( tam > 1500 ) {
#ifdef ESPANHA
         fprintf(stderr, "Provablemente indico version errada\n");
#else
         fprintf(stderr, "Provavelmente informou versao errada\n");
#endif
         cv_exit(70);
      }


            /* coloca item no buffer */
            tam_long = tam;
            PUT_LONG(dest, tam_long);
            dest += TAM_TAM;

            memcpy(dest, p, tam);

            dest += TAM_ITEM(tam);

      p += tam;
   }
}



COUNT e_versao5(orig)
TEXT *orig;
{  COUNT i;
   LONG tam;

   tam = GET_LONG((UTEXT *)orig);

   if ( tam < 1500 )
      i = 0;
   else
      i = 1;

   return(i);
}


VOID cv_exit(cod)
COUNT cod;
{
   if ( novo_arquivo[0] != '\0' )
      DELFILE(novo_arquivo);

   exit(cod);
}

