#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"

#include  <string.h>

extern COUNT order;
extern COUNT tipo_exp;
extern COUNT ap_extravet;
extern TEXT  *buf_iotxt; /* buffer para io de texto e load_vet */
extern FILE *fp_exp;
extern Rel         ap_rel;


#ifdef MSDOS
   VOID  d_imp_linha_cp(Campo *, FILE *);
   COUNT d_impit_vista( TEXT *, Vet_itens * );
   COUNT d_impit_rel( TEXT *, Vet_itens * );
   COUNT acha_campo(COUNT, COUNT);
   Campo **pos_vetcmp(COUNT);
   COUNT exporta_texto(TEXT *, COUNT, TEXT *, TEXT *);
#else
   VOID  d_imp_linha_cp( );
   COUNT d_impit_vista( );
   COUNT d_impit_rel( );
   COUNT acha_campo( );
   Campo **pos_vetcmp( );
   COUNT exporta_texto( );
#endif

VOID d_imp_linha_cp(pc, fp)
Campo *pc;
FILE *fp;
{  TEXT tipo[30], desc[50];

   if ( pc->cp_desc[0] == '\0' )
      strcpy(desc, "** Sem Descricao.");
   else
      strcpy(desc, pc->cp_desc);


   switch(pc->cp_tipo) {
      case 'T' : strcpy(tipo, "Texto");         break;
      case 'N' : strcpy(tipo, "Num�rico");          break;
      case 'x' : strcpy(tipo, "Alfanum�rico");      break;
      case 'F' : strcpy(tipo, "Formula");           break;
      case 'D' : strcpy(tipo, "Data Automatica");    break;
      case 'H' : strcpy(tipo, "Hora Automatica");    break;
      case 'd' : strcpy(tipo, "Data");              break;
      case 'h' : strcpy(tipo, "Hora");              break;
      default  : strcpy(tipo, "?????????");              break;
   }


   fprintf(fp,"   Campo : %s\n", pc->cp_nome);
   fprintf(fp,"      Descricao   : %s\n", (pc->cp_desc[0] != '\0') ? pc->cp_desc : "** Sem Descricao" );
   fprintf(fp,"      Rodape      : %s\n", (pc->cp_rodape[0] != '\0') ? pc->cp_rodape : "** Nao definido" );
   fprintf(fp,"      Numero      : %d\n", pc->cp_num);
   if (pc->cp_decimais != 0 )
      fprintf(fp,"      Decimais    : %d\n", pc->cp_decimais );
   fprintf(fp,"      Tamanho     : %d\n", pc->cp_mhor );
   fprintf(fp,"      Tipo        : %s\n", tipo);
   fprintf(fp,"      Mascara     : %s\n", pc->cp_mascara );
   if (pc->cp_indexavel   == 'S') fprintf(fp,"      Indexavel   \n");
   if (pc->cp_chave_unica == 'S') fprintf(fp,"      Chave Unica \n");
   if (pc->cp_branco      == 'S') fprintf(fp,"      Indexacao de campo em branco \n");
   if (pc->cp_fonetica    == 'S') fprintf(fp,"      Indexacao fonetica    \n");
   if ( pc->cp_help[0] != '\0' )  fprintf(fp,"      Help        : %s\n", pc->cp_help);
   if ( pc->cp_tipo == 'F' )
      fprintf(fp,"      Formula  : %s\n", pc->cp_param.cp_msc_form);


   if ( pc->cp_critica != 0 && pc->cp_critica != 'N') {
      switch(pc->cp_critica) {
         case 'T' : fprintf(fp,"      Critica TABELA : %s\n", pc->cp_param.tab_auto.tabela); break;
         case 'I' : fprintf(fp,"      Critica INTERVALO : Min = %s  Max = %s\n", pc->cp_param.intervalo.cp_minimo, pc->cp_param.intervalo.cp_maximo); break;
         case 'G' : fprintf(fp,"      Critica CGC\n"); break;
         case 'C' : fprintf(fp,"      Critica CPF\n"); break;
         case 'A' : fprintf(fp,"      Critica AUTONUM : %s\n", pc->cp_param.tab_auto.autonum ); break;
         case 'M' : fprintf(fp,"      Critica MOD11\n"); break;
         default  : fprintf(fp,"      Critica ????????\n"); break;
      }
   }

   if ( pc->cp_1futuro != '\0' )
      fprintf(fp,"      futuro1 : %c\n", pc->cp_1futuro);

   if ( pc->cp_2futuro != 0 )
      fprintf(fp,"      futuro2 : %ld\n", pc->cp_2futuro);

}



F__LOC   COUNT d_impit_vista(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret, ind, tela = -1, i;
   TTela *pe;
   TEXT *p, tipo[20];
   Campo *pc;

   ret = 0;

   order = 1;

   for (ind = 0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){
      if ( pe->te_tipo == 'S' || pe->te_tipo == 'E' ) {
         i = acha_campo(BASE_EDIT, pe->te_num );
         pe->te_ivetcp = i;
      }
      else
         pe->te_ivetcp = -1;
   }



   fprintf(fp_exp,"\n\n   Vista : %s\n", nome);

   for (ind = 0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){

      p = ( SC * ) pe + sizeof( TTela );

      if ( tela != pe->te_tela ) {
         tela = pe->te_tela;
         fprintf(fp_exp,"      Tela %d\n", tela);
      }

      switch ( pe->te_tipo ) {

         case 'B' :
                     fprintf(fp_exp, "         BORDA   LinInic=%d,ColInic=%d,LinFinal=%d,ColFinal=%d,Titulo=%s\n",
                        pe->te_linha, pe->te_coluna,
                        pe->te_vver, pe->te_vhor, p);
                     break;

         case 'D' :
                     fprintf(fp_exp, "         DISPLAY Lin=%2.2d,Col=%3.3d,Titulo=%s\n",
                        pe->te_linha, pe->te_coluna, p);
                     break;

         case 'H' :
         case 'L' :
                     fprintf(fp_exp, "         LINHA%c   LinInic=%d,ColInic=%d,LinFinal=%d,ColFinal=%d\n",
                        pe->te_tipo, pe->te_linha, pe->te_coluna,
                        pe->te_vver, pe->te_vhor);
                     break;

         case 'E' :
         case 'S' :
                     if ( pe->te_tipo == 'E' ) strcpy(tipo, "CAMPO_E");
                     else                      strcpy(tipo, "CAMPO_S");

                     pc = pos_vetcmp(pe->te_icb)[pe->te_ivetcp];

                     fprintf(fp_exp, "         %s %-15.15s Lin=%2.2d,Col=%3.3d,VisVert=%d,VisHoriz=%d",
                        tipo, pc->cp_nome, pe->te_linha, pe->te_coluna,
                        pe->te_vver, pe->te_vhor);
                     if ( pe->te_autoclear   == 'S' ) fprintf(fp_exp,",Autoclear" );
                     if ( pe->te_obrigatorio == 'S' ) fprintf(fp_exp,",Obrigatorio");
                     if ( pe->te_append == 'S' )      fprintf(fp_exp,",Append");
                     fprintf(fp_exp,"\n");
                     break;

         default :
                     fprintf(fp_exp, "         Item Desconhecido\n", pe->te_tipo);
                     break;
      };

   };

fim :

   return(ret);
}


F__LOC   COUNT d_impit_rel(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret, ind, tela = -1, i;
   RTela *te;
   TEXT *p, tipo[20];
   Campo *pc;

   ret = 0;

   order = 1;

   for (ind = 0; (te = (RTela *)vi->vi_vtit[ind]) != NULL; ind++ ){
      if ( te->re_tipo == 'S' || te->re_tipo == 'E' ) {
         i = acha_campo(BASE_EDIT, te->re_num );
         te->re_ivetcp = i;
      }
      else
         te->re_ivetcp = -1;
   }

   fprintf(fp_exp,"\n\n   Relatorio : %s\n", nome);
   fprintf(fp_exp,      "      Tipo   : %c\n", ap_rel.rel_tipo);

   switch ( ap_rel.rel_tipo ) {
      case 'F' :
      case 'C' :
         fprintf(fp_exp,"      Titulo : %s\n", (ap_rel.rel_titulo[0] != '\0') ? ap_rel.rel_titulo : "** Indefinido");
         fprintf(fp_exp,"      rodape : %s\n", (ap_rel.rel_rodape[0] != '\0') ? ap_rel.rel_rodape : "** Indefinido");
         fprintf(fp_exp,"      Tamanho Vertical  : %d\n", ap_rel.rel_linhas);
         fprintf(fp_exp,"      Tamanho Horizontal: %d\n", ap_rel.rel_colunas);
         fprintf(fp_exp,"      Imprime Cabecalho : %s\n", (ap_rel.rel_cabec == 'S') ? "Sim" : "Nao");
         fprintf(fp_exp,"      Tipo de Caracter  : %s\n", (ap_rel.rel_caracter == 'C') ? "Comprimido" : "Normal");
         fprintf(fp_exp,"      Qualid. Impressao : %s\n", (ap_rel.rel_qualid   == 'C') ? "Carta" : "Normal");
         fprintf(fp_exp,"      Imp. Folha Solta  : %s\n", (ap_rel.rel_folha    == 'S') ? "Sim" : "Nao");
         break;

      case 'E' :
         fprintf(fp_exp,"      Tamanho Etiqueta (linhas)              : %d\n", ap_rel.rel_linhas);
         fprintf(fp_exp,"      Tamanho Etiqueta (Colunas)             : %d\n", ap_rel.rel_colunas);
         fprintf(fp_exp,"      Intervalo entre Etiquetas (em linhas)  : %d\n", ap_rel.rel_l_inter);
         fprintf(fp_exp,"      Intervalo entre Etiquetas (em colunas) : %d\n", ap_rel.rel_c_inter);
         fprintf(fp_exp,"      Numero de Etiquetas na linha           : %d\n", ap_rel.rel_n_etq);
         break;
   }


   if ( ap_rel.rel_1numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_1numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];
         if ( ap_rel.rel_tipo == 'E' ) {
            fprintf(fp_exp, "      Ordenacao Primaria   : Campo %-15.15s  Ordem : %c\n",
               pc->cp_nome, ap_rel.rel_1ord);
         }
         else {
            fprintf(fp_exp, "      Ordenacao Primaria   : Campo %-15.15s  Ordem : %c  Qtd.Lin %2.2d  Totaliza: %c\n",
               pc->cp_nome, ap_rel.rel_1ord, ap_rel.rel_1linhas, ap_rel.rel_1total);
         }
      }
   }

   if ( ap_rel.rel_2numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_2numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];
         if ( ap_rel.rel_tipo == 'E' ) {
            fprintf(fp_exp, "      Ordenacao Secundaria : Campo %-15.15s  Ordem : %c\n",
               pc->cp_nome, ap_rel.rel_2ord);

         }
         else {
            fprintf(fp_exp, "      Ordenacao Secundaria : Campo %-15.15s  Ordem : %c  Qtd.Lin %2.2d  Totaliza: %c\n",
               pc->cp_nome, ap_rel.rel_2ord, ap_rel.rel_2linhas, ap_rel.rel_2total);

         }
      }
   }

   if ( ap_rel.rel_3numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_3numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];

         if ( ap_rel.rel_tipo == 'E' ) {
            fprintf(fp_exp, "      Ordenacao Terciaria  : Campo %-15.15s  Ordem : %c\n",
               pc->cp_nome, ap_rel.rel_3ord);
         }
         else {
            fprintf(fp_exp, "      Ordenacao Terciaria  : Campo %-15.15s  Ordem : %c  Qtd.Lin %2.2d  Totaliza: %c\n",
               pc->cp_nome, ap_rel.rel_3ord, ap_rel.rel_3linhas, ap_rel.rel_3total);
         }
      }
   }

   if ( ap_extravet ) {
      fprintf(fp_exp,"      Caracteristicas Especiais :\n");
      exporta_texto(buf_iotxt, ap_extravet, "         ", "");
   }


   for (ind = 0; (te = (RTela *)vi->vi_vtit[ind]) != NULL; ind++ ) {

      p = ( SC * ) te + sizeof( RTela );

      if ( tela != te->re_tela ) {
         tela = te->re_tela;
         fprintf(fp_exp,"      Tela %d\n", tela);
      }

      switch ( te->re_tipo ) {

         case 'B' :
                     fprintf(fp_exp, "         BORDA   LinInic=%d,ColInic=%d,LinFinal=%d,ColFinal=%d,Titulo=%s\n",
                        te->re_linha, te->re_coluna,
                        te->re_vver, te->re_vhor, p);
                     break;

         case 'D' :
                     fprintf(fp_exp, "         DISPLAY Lin=%d,Col=%d,Titulo=%s\n",
                        te->re_linha, te->re_coluna, p);
                     break;

         case 'H' :
         case 'L' :
                     fprintf(fp_exp, "         LINHA%c   LinInic=%d,ColInic=%d,LinFinal=%d,ColFinal=%d\n",
                        te->re_tipo, te->re_linha, te->re_coluna,
                        te->re_vver, te->re_vhor);
                     break;

         case 'E' :
         case 'S' :
                     if ( te->re_tipo == 'E' ) strcpy(tipo, "CAMPO_E");
                     else                      strcpy(tipo, "CAMPO_S");

                     pc = pos_vetcmp(te->re_icb)[te->re_ivetcp];

                     fprintf(fp_exp, "         %s Lin=%d,Col=%d,VisVert=%d,VisHoriz=%d,Campo=%s\n",
                        tipo, te->re_linha, te->re_coluna,
                        te->re_vver, te->re_vhor,pc->cp_nome);

                     if ( te->re_tot    == 'S' ) fprintf(fp_exp, "            Totaliza\n");
                     if ( te->re_quant  == 'S' ) fprintf(fp_exp, "            Quantifica\n");
                     if ( te->re_media  == 'S' ) fprintf(fp_exp, "            Media\n");
                     if ( te->re_desvio == 'S' ) fprintf(fp_exp, "            Desvio\n");
                     break;

         default :
                     fprintf(fp_exp, "         Item Desconhecido\n", te->re_tipo);
                     break;
      };
   };


fim :

   return(ret);
}

