#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"

#include  <string.h>

extern COUNT order;
extern COUNT tipo_exp;
extern COUNT ap_extravet;
extern TEXT  *buf_iotxt; /* buffer para io de texto e load_vet */
extern FILE *fp_exp;
extern Rel         ap_rel;
extern Vista       ap_vista;

#ifdef MSDOS
   VOID  e_imp_linha_cp(Campo *, FILE *);
   COUNT e_impit_vista( TEXT *, Vet_itens * );
   COUNT e_impit_rel( TEXT *, Vet_itens * );
   COUNT acha_campo(COUNT, COUNT);
   Campo **pos_vetcmp(COUNT);
   COUNT exporta_texto(TEXT *, COUNT, TEXT *, TEXT *);
#else
   VOID  e_imp_linha_cp( );
   COUNT e_impit_vista( );
   COUNT e_impit_rel( );
   COUNT acha_campo( );
   Campo **pos_vetcmp( );
   COUNT exporta_texto( );
#endif

VOID e_imp_linha_cp(pc, fp)
Campo *pc;
FILE *fp;
{
   fprintf(fp_exp,"@@CPI\n");
   fprintf(fp,"NM %s\n", pc->cp_nome);
   fprintf(fp,"OR %d\n", pc->cp_ordem       );
   fprintf(fp,"NU %d\n", pc->cp_num         );
   fprintf(fp,"DC %d\n", pc->cp_decimais    );
   if ( pc->cp_desc[0] != '\0' ) fprintf(fp,"DE %s\n", pc->cp_desc        );
   fprintf(fp,"MH %d\n", pc->cp_mhor        );
/*   fprintf(fp,"TA %d\n", pc->cp_a_tam       ); */
   fprintf(fp,"TP %c\n", pc->cp_tipo        );
/*   fprintf(fp,"PA %c\n", pc->cp_a_tipo      ); */
   fprintf(fp,"MS %s\n", pc->cp_mascara     );
   if ( pc->cp_chave_unica != 'N'  ) fprintf(fp,"CU %c\n", pc->cp_chave_unica );
   if ( pc->cp_branco      != 'N'  ) fprintf(fp,"CB %c\n", pc->cp_branco      );
   if ( pc->cp_fonetica    != 'N'  ) fprintf(fp,"CF %c\n", pc->cp_fonetica    );
   if ( pc->cp_indexavel   != 'S'  ) fprintf(fp,"CI %c\n", pc->cp_indexavel   );
   if ( pc->cp_rodape[0]   != '\0' ) fprintf(fp,"CR %s\n", pc->cp_rodape      );
   if ( pc->cp_help[0]     != '\0' ) fprintf(fp,"CH %s\n", pc->cp_help        );
   if ( pc->cp_critica     != 'N'  ) fprintf(fp,"CC %c\n", pc->cp_critica     );
   if ( pc->cp_critica == 'T' )
      fprintf(fp,"VT %s\n", pc->cp_param.tab_auto.tabela );
   if ( pc->cp_critica == 'I' ) {
      fprintf(fp,"VM %s\n", pc->cp_param.intervalo.cp_maximo);
      fprintf(fp,"Vm %s\n", pc->cp_param.intervalo.cp_minimo);
   }
   if ( pc->cp_critica == 'A' )
      fprintf(fp,"VA %s\n", pc->cp_param.tab_auto.autonum );

   if ( pc->cp_tipo == 'F' )
      fprintf(fp,"FM %s\n", pc->cp_param.cp_msc_form);

   fprintf(fp_exp,"@@CPF\n");

}




F__LOC   COUNT e_impit_vista(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret, ind, i;
   TTela *pe;
   TEXT *p;
   Campo *pc;

   ret = 0;

   order = 1;

   for (ind = 0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){
      if ( pe->te_tipo == 'S' || pe->te_tipo == 'E' ) {
         i = acha_campo(BASE_EDIT, pe->te_num );
         pe->te_ivetcp = i;
      }
      else
         pe->te_ivetcp = -1;
   }

   fprintf(fp_exp, "@@VSI %s\n", nome);
   fprintf(fp_exp, "VNO %s\n", ap_vista.vis_ident);
   fprintf(fp_exp, "VOR %d\n", ap_vista.vis_ordem);
   fprintf(fp_exp, "@@VSF %s\n", nome);


   for (ind = 0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){

      p = ( SC * ) pe + sizeof( TTela );

      fprintf(fp_exp,"@IVI %d\n", ind);
      if ( pe->te_append == 'S' ) fprintf(fp_exp,"CA %c\n", pe->te_append    );
      if ( pe->te_tela   !=  1  ) fprintf(fp_exp,"TL %d\n", pe->te_tela      );
      fprintf(fp_exp,"TP %c\n", pe->te_tipo      );
      fprintf(fp_exp,"NM %d\n", pe->te_num       );
      fprintf(fp_exp,"LI %d\n", pe->te_linha     );
      fprintf(fp_exp,"CO %d\n", pe->te_coluna    );
      fprintf(fp_exp,"VV %d\n", pe->te_vver      );
      fprintf(fp_exp,"VH %d\n", pe->te_vhor      );
      if ( pe->te_autoclear   == 'S' ) fprintf(fp_exp,"AC %c\n", pe->te_autoclear );
      if ( pe->te_obrigatorio == 'S' ) fprintf(fp_exp,"OB %c\n", pe->te_obrigatorio);
      if ( *p != '\0' )                fprintf(fp_exp,"TX %s\n", p);

      if ( pe->te_ivetcp != -1 ) {
         pc = pos_vetcmp(pe->te_icb)[pe->te_ivetcp];
         fprintf(fp_exp,"NC %s\n", pc->cp_nome);
      }

      fprintf(fp_exp,"@IVF %d\n", ind);

   };

   fprintf(fp_exp,"@@VIF %d\n", ind); /* fim do vetor de itens de Vista */

fim :

   return(ret);
}




/*=====================================================================*/

F__LOC   COUNT e_impit_rel(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret, ind, i;
   RTela *te;
   TEXT *p;
   Campo *pc;

   ret = 0;

   order = 1;

   for (ind = 0; (te = (RTela *)vi->vi_vtit[ind]) != NULL; ind++ ){
      if ( te->re_tipo == 'S' || te->re_tipo == 'E' ) {
         i = acha_campo(BASE_EDIT, te->re_num );
         te->re_ivetcp = i;
      }
      else
         te->re_ivetcp = -1;
   }

   fprintf(fp_exp, "@@RLI %s\n", nome);
   fprintf(fp_exp, "NO %s\n", ap_rel.rel_ident);
   fprintf(fp_exp, "OR %d\n", ap_rel.rel_ordem);
   fprintf(fp_exp, "NI %d\n", ap_rel.rel_n_elem);
   fprintf(fp_exp, "TI %s\n", ap_rel.rel_titulo);
   fprintf(fp_exp, "RO %s\n", ap_rel.rel_rodape);
   fprintf(fp_exp, "TP %c\n", ap_rel.rel_tipo);
   fprintf(fp_exp, "CI %c\n", ap_rel.rel_cabec);
   fprintf(fp_exp, "NL %d\n", ap_rel.rel_linhas);
   fprintf(fp_exp, "NC %d\n", ap_rel.rel_colunas);
   fprintf(fp_exp, "IL %d\n", ap_rel.rel_l_inter);
   fprintf(fp_exp, "IC %d\n", ap_rel.rel_c_inter);
   fprintf(fp_exp, "NE %d\n", ap_rel.rel_n_etq);
   fprintf(fp_exp, "CA %c\n", ap_rel.rel_caracter);
   fprintf(fp_exp, "QL %c\n", ap_rel.rel_qualid);
   fprintf(fp_exp, "FS %c\n", ap_rel.rel_folha);

   if ( ap_rel.rel_1numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_1numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];
         fprintf(fp_exp, "O1 %s,%c,%d,%c\n",
            pc->cp_nome, ap_rel.rel_1ord, ap_rel.rel_1linhas, ap_rel.rel_1total);
      }
   }

   if ( ap_rel.rel_2numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_2numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];
         fprintf(fp_exp, "O2 %s,%c,%d,%c\n",
            pc->cp_nome, ap_rel.rel_2ord, ap_rel.rel_2linhas, ap_rel.rel_2total);
      }
   }

   if ( ap_rel.rel_3numcampo >= 0 ) {
      if ( (i = acha_campo(BASE_EDIT, ap_rel.rel_3numcampo)) >= 0 ) {
         pc = pos_vetcmp(BASE_EDIT)[i];
         fprintf(fp_exp, "O3 %s,%c,%d,%c\n",
            pc->cp_nome, ap_rel.rel_3ord, ap_rel.rel_3linhas, ap_rel.rel_3total);
      }
   }


   fprintf(fp_exp, "@@RLF %s\n", nome);


   for (ind = 0; (te = (RTela *)vi->vi_vtit[ind]) != NULL; ind++ ){

      p = ( SC * ) te + sizeof( RTela );

      fprintf(fp_exp,"@IRI %d\n", ind);
      if ( te->re_uv    != 0 ) fprintf(fp_exp,"UV %d\n", te->re_uv);
      if ( te->re_tela  != 1 ) fprintf(fp_exp,"TL %d\n", te->re_tela);
      fprintf(fp_exp,"TP %c\n", te->re_tipo);
      fprintf(fp_exp,"NM %d\n", te->re_num);
      fprintf(fp_exp,"LI %d\n", te->re_linha);
      fprintf(fp_exp,"CO %d\n", te->re_coluna);
      fprintf(fp_exp,"VV %d\n", te->re_vver);
      fprintf(fp_exp,"VH %d\n", te->re_vhor);
      if ( te->re_tot    == 'S' ) fprintf(fp_exp,"TO %c\n", te->re_tot);
      if ( te->re_quant  == 'S' ) fprintf(fp_exp,"QT %c\n", te->re_quant);
      if ( te->re_media  == 'S' ) fprintf(fp_exp,"MD %c\n", te->re_media);
      if ( te->re_desvio == 'S' ) fprintf(fp_exp,"DV %c\n", te->re_desvio);
      if ( *p != '\0' ) fprintf(fp_exp,"TX %s\n", p);

      if ( te->re_ivetcp != -1 ) {
         pc = pos_vetcmp(te->re_icb)[te->re_ivetcp];
         fprintf(fp_exp,"NC %s\n", pc->cp_nome);
      }

      fprintf(fp_exp,"@IRF %d\n", ind);
   };


   if ( ap_extravet ) {
      fprintf(fp_exp,"@@EVI\n");
      exporta_texto(buf_iotxt, ap_extravet, "@@EV ", "");
   }

   fprintf(fp_exp,"@@RIF %d\n", ind); /* fim do vetor de itens de Vista */

fim :

   return(ret);
}

