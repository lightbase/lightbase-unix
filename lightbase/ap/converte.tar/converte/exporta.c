#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"
#include  "lb2vet.h"

#include  <string.h>
#include  <ctype.h>
#include  <time.h>

#ifdef MSDOS
#include  <mem.h>
#include  <dir.h>
#include  <io.h>
long farcoreleft(void);
TEXT   *w_memmove( TEXT *, TEXT *, US );
#else
TEXT   *w_memmove( );
#endif

#include  "../../ct/cteproto.h"
#include  "../../ct/ctdefs.h"
#include  "../../ct/cterrc.h"

COUNT ap_sizeio = (UCOUNT)65000L;
COUNT ap_extravet = 0;
COUNT release;
COUNT ap_mxelem;

#define CONST   1227 /* constante para mascarar numeros chaves da base (chute) */

COUNT mapeia_cv, mapa_cv[300];

Base        rec_base, *WBS;
POINTER     lb4_pos;
Base        *v_bases[2];
Desc_base   *c_bases[2], dbase, *WCB;

Vet_itens   *v_campos[2];
Vista       ap_vista;
Rel         ap_rel;
TEXT        *buf_iotxt; /* buffer para io de texto e load_vet */
COUNT       lb4_old,
            lb4_new;
LONG        num_serie;
UCOUNT       id_arq;
TEXT path_base[100];
TEXT path_out[100];



struct hdtxt {
   UTEXT txt_marca;
   LONG  txt_record;
   UTEXT txt_campo;
   UTEXT txt_parte;
   POINTER txt_proximo;
} *p_hdtxt;




POINTER pos_hdr;
POINTER pos_stp;
POINTER pos_campos;
POINTER pos_vistas;
POINTER pos_relats;
POINTER pos_ivis[MAX_VISTAS+2];
POINTER pos_irel[MAX_VISTAS+2];
COUNT indvis, indrel;
FILE *fp_exp;
FILE *fp_aux;
FILE *fp_lb4;
COUNT order;
COUNT tipo_exp;
COUNT depura=0;

Vet_itens *v;

#define     MARCA_REGISTRO 254
#define     MARCA_TEXTO    255

/* #define     BASE_EDIT  0 */

#define   MAX(x,y)        (((x)>(y))?(x):(y))
#define   MIN(x,y)        (((x)<(y))?(x):(y))
#define   debug(x)        fprintf(stderr, "%s\n", x);

#define   BS  'B'
#define   CP  'C'
#define   VS  'V'
#define   IV  'I'
#define   RE  'R'
#define   IR  'L'
#define   SW  'S'

#define     CAMPO_G 'G'  /*** CAMPO GENERICO - ENTRADA ou SAIDA ***/
#define     CAMPO_S 'S'
#define     CAMPO_E 'E'




#ifdef MSDOS
   VOID  sintaxe(VOID);
   COUNT analiza_velho(VOID);
   COUNT ident_reg( TEXT *, UCOUNT, COUNT *);
   VOID cria_novo(TEXT *);
   COUNT trata_conteudo(VOID);
   COUNT recupera_campos( VOID );
   COUNT consiste_vistas( VOID );
   COUNT consiste_relats( VOID );
   POINTER salva_itens(Vet_itens *);
   VOID vs_cvcampo(Vet_itens *);
   VOID rl_cvcampo(Vet_itens *);
   COUNT e_versao5(TEXT *);
   VOID cv_exit( COUNT );
   VOID d_imp_linha_cp(Campo *, FILE *);
   VOID e_imp_linha_cp(Campo *, FILE *);
   VOID w_imp_linha_cp(Campo *, FILE *);
   VOID tira_virgula(TEXT *);
   COUNT d_impit_vista( TEXT *, Vet_itens * );
   COUNT e_impit_vista( TEXT *, Vet_itens * );
   COUNT w_impit_vista( TEXT *, Vet_itens * );
   COUNT d_impit_rel( TEXT *, Vet_itens * );
   COUNT e_impit_rel( TEXT *, Vet_itens * );
   COUNT w_impit_rel( TEXT *, Vet_itens * );
   COUNT sai_linha(COUNT, TEXT *, TEXT *);
   COUNT sai_campo(COUNT *, COUNT, COUNT, COUNT, COUNT, COUNT, TEXT *, COUNT);
   COUNT exporta_texto(TEXT *, COUNT, TEXT *, TEXT *);
#else
   VOID  sintaxe( );
   COUNT analiza_velho( );
   COUNT ident_reg( );
   VOID cria_novo( );
   COUNT trata_conteudo( );
   COUNT recupera_campos( );
   COUNT consiste_vistas( );
   COUNT consiste_relats( );
   POINTER salva_itens( );
   VOID vs_cvcampo( );
   VOID rl_cvcampo( );
   COUNT e_versao5( );
   VOID cv_exit( );
   VOID d_imp_linha_cp( );
   VOID e_imp_linha_cp( );
   VOID w_imp_linha_cp( );
   VOID tira_virgula( );
   COUNT d_impit_vista( );
   COUNT e_impit_vista( );
   COUNT w_impit_vista( );
   COUNT d_impit_rel( );
   COUNT e_impit_rel( );
   COUNT w_impit_rel( );
   COUNT sai_linha( );
   COUNT sai_campo( );
   COUNT exporta_texto( );
#endif



#ifdef MSDOS
   /** lb2but1    ***********************************************************/
   Campo **pos_vetcmp(COUNT);
   COUNT qtd_vetcmp(COUNT);
   Vet_itens *load_campos(COUNT, COUNT);
   VOID rlse_campos(COUNT);
   COUNT acha_campo(COUNT, COUNT);
   COUNT ver_campo(COUNT, TEXT *, COUNT *);
   TEXT *sel_campo(COUNT, Campo **, COUNT);
   Vet_itens *load_vistas(COUNT, COUNT);
   Vet_itens *load_itvis(Vista *, COUNT);
   TTela *pos_itvis(COUNT);
   COUNT qtd_itvis(VOID);
   Vet_itens *load_rels(COUNT, COUNT);
   Vet_itens *load_itrel(Rel *, COUNT);
   RTela *pos_itrel(COUNT);
   COUNT qtd_itrel(VOID);
#else
   Campo **pos_vetcmp( );
   COUNT qtd_vetcmp( );
   Vet_itens *load_campos( );
   VOID rlse_campos( );
   COUNT acha_campo( );
   COUNT ver_campo( );
   TEXT *sel_campo( );
   Vet_itens *load_vistas( );
   Vet_itens *load_itvis( );
   TTela *pos_itvis( );
   COUNT qtd_itvis( );
   Vet_itens *load_rels( );
   Vet_itens *load_itrel( );
   RTela *pos_itrel( );
   COUNT qtd_itrel( );
#endif




#ifndef GET_LONG
F__GLB   LONG GET_LONG(p)
UTEXT *p;
{  LONG l;
   UTEXT *pc;
   pc = (UTEXT*)&l;

   *pc++ = *p++;
   *pc++ = *p++;
   *pc++ = *p++;
   *pc = *p;
   return(l);
}
#endif


TEXT  *w_memmove( dest, orig, tam )

TEXT  *dest, *orig;
US  tam;
{
   US   I;
   register TEXT   *A, *B;

   A = dest;
   B = orig;

   if ( A > B )
   {
      A += tam - 1;
      B += tam - 1;

      for ( I = 0;   I < tam;   I++ )   *A-- = *B--;
   }

   else
   {
      for ( I = 0;   I < tam;   I++ )   *A++ = *B++;
   }

   return ( orig );
}




main(argc, argv)
int argc;
char **argv;
{  COUNT ret, i;
   TEXT arquivo_in[80], arquivo_cmp[80], arquivo_vis[80], base[30];

   ap_mxelem = MAX_ELEM;


   WBS = v_bases[0] = &rec_base;
   WCB = c_bases[0] = &dbase;
   c_bases[0]->cb_tpopen = 0;


   printf("Exportador de definicao de Base de dados\n");
   printf("Versao 2.3\n");
   printf("Light Software Ltda\n\n\n");

   base[0] = '\0';
   tipo_exp = 0;


   for ( i=1; i < argc; i++ ) {
      if ( argv[i][0] == '?' ) {
         sintaxe();
         return(0);
      }

      if ( argv[i][0] != '-' ) {
         if ( base[0] != '\0' ) {
            sintaxe();
            return(0);
         }
         strcpy(base, argv[i]);
         continue;
      }
      else {
         if ( toupper(argv[i][1]) == 'L' || toupper(argv[i][1]) == 'E'  ) {
           tipo_exp = 'E';
         }
         else if ( toupper(argv[i][1]) == 'W' ) {
           tipo_exp = 'W';
         }
         else if ( toupper(argv[i][1]) == 'D' ) {
           tipo_exp = 'D';
         }
         else if ( toupper(argv[i][1]) == 'P' ) {
            if ( argv[i][2] == '\0') {
               sintaxe();
               return(0);
            }
            strcpy(path_base, &argv[i][2]);
         }
         else if ( toupper(argv[i][1]) == 'O' ) {
            if ( argv[i][2] == '\0') {
               sintaxe();
               return(0);
            }
            strcpy(path_out, &argv[i][2]);
         }
         else if ( toupper(argv[i][1]) == '?' ) {
            sintaxe();
            return(0);
         }
         else if ( toupper(argv[i][1]) == 'T' ) {
           depura = 1;
         }
         else if ( toupper(argv[i][1]) == 'M' ) {
           ap_mxelem = atoi(&argv[i][2]);
           if ( ap_mxelem < 200 || ap_mxelem > 400 )
              ap_mxelem = 200;
         }
      }
   }

   /* Seleciona formato de exportacao */
   while ( tipo_exp == 0 ) {
      TEXT aux[200];
      printf("Formato de exportacao :\n");
      printf("   W ) LightBase For Windows\n");
      printf("   D ) Documentacao de Base\n");
      printf("   L ) Light Base - Importacao (DOS/UNIX)\n\n");
      printf("   Selecione o formato desejado : ");
      gets(aux);
      if (aux[0] == '\0' )
         return(0);
      switch(toupper(aux[0])) {
         case 'W' :  tipo_exp = 'W'; break;
         case 'D' :  tipo_exp = 'D'; break;
         case 'L' :
         case 'E' :  tipo_exp = 'E'; break;
      }
   }

   while ( base[0] == '\0' ) {
      TEXT aux[200], *p;

      printf("Base a ser exportada : ");
      gets(aux);
      if (aux[0] == '\0' )
         return(0);

      if ( (p=strstr(aux, ".lb4")) != NULL )
         *p = '\0';
      if ( (p=strstr(aux, ".LB4")) != NULL )
         *p = '\0';

      if ( strchr(aux, '.') != NULL || strchr(aux, '/') != NULL || strchr(aux, '\\') != NULL ) {
         printf("Para especificar o diretorio da base, use a opcao -P\n\n");
         continue;
      }
      else {
         strcpy(base, aux);
         break;
      }
   }

   if ( path_base[0] != '\0' )
      sprintf(arquivo_in, "%s%c%s.lb4", path_base, BARRA, base);
   else {
      strcpy(arquivo_in, base);
      strcat(arquivo_in, ".lb4");
   }


   if ( path_out[0] != '\0' ) {
      sprintf(arquivo_cmp, "%s%c%s.txt", path_out, BARRA, base);
      sprintf(arquivo_vis, "%s%c%s.lbe", path_out, BARRA, base);
   }
   else {
      strcpy(arquivo_cmp, base);
      strcat(arquivo_cmp, ".txt");
      strcpy(arquivo_vis, base);
      strcat(arquivo_vis, ".lbe");
   }


   if ( access(arquivo_in, 0) != 0 ) {
      printf("Arquivo de descricao da base nao existe. %s\n", arquivo_in);
      cv_exit(1);
   }


   if ( INTREE(6, 5, 8) ) {
      fprintf(stderr, "Nao inicializou CT\n");
      cv_exit(1);
   }

   lb4_old = 1;


   /* faz com que MANUT_OPEN so sete as variaveis abaixo e mantenha arquivo fechado */
   num_serie = 0L;
   id_arq = 999;

   MANUT_OPEN( lb4_old, arquivo_in, 'V', &num_serie, &id_arq );

   if ( uerr_cod != IDBASE_ERR ) {
      fprintf(stderr, "Arquivo danificado. Nao posso abrir. Erro : %d\n", uerr_cod);
      fprintf(stderr, "Contacte seu revendedor\n");
      cv_exit(1);
   }


   ret = MANUT_OPEN( lb4_old, arquivo_in, 'V', &num_serie, &id_arq );

   if ( ret != FCRP_ERR && ret != NO_ERROR ) {
      fprintf(stderr, "Atencao. Erro No : %d . Reporte ao fornecedor\n", 18);
      cv_exit(2);
   }


   if ( (fp_exp = fopen(arquivo_cmp, "w")) == NULL ) {
      fprintf(stderr, "Erro na abertura do arquivo %s\n", arquivo_cmp);
      exit(1);
   }

   if ( tipo_exp == 'W' ) {
      if ( (fp_aux = fopen(arquivo_vis, "w")) == NULL ) {
         fprintf(stderr, "Erro na abertura do arquivo %s\n", arquivo_vis);
         exit(1);
      }
   }

   if ( (buf_iotxt = malloc((UCOUNT)65000L)) == NULL ) {
      fprintf(stderr, "Sem Memoria");
      cv_exit(9);
   }


   analiza_velho();

   printf("\n\nIniciando Geracao de informacoes detectadas no Arquivo LB4\n");

   switch(tipo_exp) {
      case 'D' :
                  fprintf(fp_exp,"BASE : %s:\n", rec_base.bs_nome);
                  fprintf(fp_exp,"=============================================================================\n");
                  fprintf(fp_exp,"   Nome              : %s\n", rec_base.bs_nome);
                  fprintf(fp_exp,"   Descri��o da Base : %s\n",(rec_base.bs_desc[0] != '\0') ? rec_base.bs_desc: "**Sem Descricao");
                  fprintf(fp_exp,"   Path              : %s\n", rec_base.bs_path);
                  fprintf(fp_exp,"   Dono              : %s\n", rec_base.bs_dono);
                  fprintf(fp_exp,"   Grupo             : %s\n", rec_base.bs_grupo);
/*                fprintf(fp_exp,"   Id_base           : %ud\n", rec_base.bs_idbase); */
                  fprintf(fp_exp,"   Num. Serie        : %ld\n", rec_base.bs_nserie);
/*                fprintf(fp_exp,"   Xor               : %ud\n", rec_base.bs_xor); */
                  fprintf(fp_exp,"   Versao            : %ld\n", rec_base.bs_versao);
                  fprintf(fp_exp,"   Sep. Decimal      : %c\n",  rec_base.bs_sepdecimal);
                  if ( rec_base.bs_cr_data != 0L )
                     fprintf(fp_exp,"   Data Criacao      : %s",  ctime((time_t *)(&rec_base.bs_cr_data)));
                  if ( rec_base.bs_al_data != 0L )
                     fprintf(fp_exp,"   Data Alteracao    : %s",  ctime((time_t *)(&rec_base.bs_al_data)));
                  if ( rec_base.bs_bk_data != 0L )
                     fprintf(fp_exp,"   Data Backup       : %s",  ctime((time_t *)(&rec_base.bs_bk_data)));
/*                fprintf(fp_exp,"   bs_finger         : %ud\n",  rec_base.bs_finger); */
                  break;
      case 'E' :
                  fprintf(fp_exp,"@@BSI\n");
                  fprintf(fp_exp,"NM %s\n",  rec_base.bs_nome);
                  fprintf(fp_exp,"DS %s\n",  rec_base.bs_desc);
                  fprintf(fp_exp,"PT %s\n",  rec_base.bs_path);
                  fprintf(fp_exp,"DN %s\n",  rec_base.bs_dono);
                  fprintf(fp_exp,"GR %s\n",  rec_base.bs_grupo);
                  fprintf(fp_exp,"CN %ld,%ld,%ld,%ld\n",
                     (rec_base.bs_idbase == 0L ) ? 0 : (LONG)rec_base.bs_idbase + CONST,
                     (rec_base.bs_nserie == 0L ) ? 0 : (LONG)rec_base.bs_nserie,
                     (rec_base.bs_xor    == 0L ) ? 0 : (LONG)rec_base.bs_xor + CONST,
                     (rec_base.bs_finger == 0L ) ? 0 : (LONG)rec_base.bs_finger + CONST);
                  fprintf(fp_exp,"VR %d\n", rec_base.bs_versao);
                  fprintf(fp_exp,"SD %c\n",  rec_base.bs_sepdecimal);
                  fprintf(fp_exp,"DC %ld\n",  rec_base.bs_cr_data);
                  fprintf(fp_exp,"DA %ld\n",  rec_base.bs_al_data);
                  fprintf(fp_exp,"DB %ld\n",  rec_base.bs_bk_data);
                  fprintf(fp_exp,"@@BSF\n");
                  break;
      case 'W' :
                  fprintf(fp_exp,"@DB Descri��o da Base:\n");
                  fprintf(fp_exp,"%s\n\n",(rec_base.bs_desc[0] != '\0') ? rec_base.bs_desc: "**Sem Descricao");
                  break;
   }

   trata_conteudo();

   if ( depura ) {
      if ( pos_campos != 0 ) {
         TEXT a1,a2,a3,a4;
         a1=a2=a3=a4=' ';
         if ( pos_campos != 0 ) a1 = 'C';
         if ( pos_vistas != 0 ) a2 = 'V';
         if ( pos_relats != 0 ) a3 = 'R';
         if ( pos_stp    != 0 ) a4 = 'W';
         fprintf(stderr, "Base %s exportada %c%c%c%c\n", WBS->bs_nome, a1,a2,a3,a4);
      }
      else
         fprintf(stderr, "Base %s. Nao localizou campos\n", WBS->bs_nome);
   }

   return(0);
}



COUNT analiza_velho()
{  COUNT ret=0, status, ordem, tpreg, sai=0;
   UCOUNT tamanho, livre;
   POINTER pos, proximo;


   indvis = indrel = 0;

   pos   = (POINTER)0;

   printf("Processando registros da base. Aguarde...\n");

   while ( ! sai ) {

      ret = REG_INFO(lb4_old, pos, &tamanho, &livre, &proximo, &status);

      if ( pos == (POINTER) 0L )
         goto cont;

      if ( ret == READ_ERR || ret == LEOF_ERR ) {
         sai = 1;
         continue;
      }

      if ( ret != NO_ERROR || tamanho == 0 )
         goto cont;


      ret = REG_READ(lb4_old, pos, tamanho, buf_iotxt);

      if ( ret != NO_ERROR ) {
         fprintf(stderr, "Possivel perda de informacoes pos = %ld", pos);
         break;
      }

      tpreg = ident_reg( buf_iotxt, tamanho, &ordem);

      if ( tpreg != 0 ) {
         switch(tpreg) {
            case 'C' :  pos_campos = pos; break;
            case 'S' :  pos_stp = pos;    break;
            case 'B' :  pos_hdr = pos;
                        memcpy((TEXT *) &rec_base, buf_iotxt, sizeof(rec_base));
                        release = rec_base.bs_versao;

                        break;
            case 'V' :  pos_vistas = pos;
                        break;
            case 'R' :  pos_relats = pos;
                        break;
            case 'I' :  indvis++;
                        if (indvis > MAX_VISTAS ) {
                           fprintf(stderr, "Numero da vista > que %d (%d)\n", MAX_VISTAS, indvis);
                           indvis=MAX_VISTAS;
                        }
                        pos_ivis[indvis] = pos;
                        break;
            case 'L' :  indrel++;
                        if (indrel > MAX_VISTAS ) {
                           fprintf(stderr, "Numero do relatorio > que %d (%d)\n", MAX_VISTAS, indvis);
                           indrel=MAX_VISTAS;
                        }
                        pos_irel[indrel] = pos;
                        break;

            default        : fprintf(stderr, "Informacao nao reconhecida na descricao da base\n");
         }
      }

cont:

      if ( proximo == (POINTER) 0 ) sai = 1;
      else                pos = proximo;

   }

   ret = 0;

fim :

   return(ret);
}


COUNT ident_reg( buf, tam, ordem)
TEXT *buf;
UCOUNT tam;
COUNT *ordem;
{  COUNT ret, n=0;
   Hdr_bloco *hdr;

#ifdef PA800R
   n = 3; /* Alinha estrutura */
#endif

   *ordem = 0;
   ret = 0;

if (depura)
   fprintf(stderr, "buf[0] = %d\n", (UTEXT)buf[0]);
   /* Stop Words tem numero de registro 0000 */
  if ( (UTEXT)buf[0] == MARCA_TEXTO) {
      printf("Localizadas Stop_words\n");
      ret = SW;
      goto fim;
   }


   if ( tam == sizeof(Base)) {
      Base *pb;
      pb = (Base *)buf;
      if ( pb->bs_marca[0] == 'B' && pb->bs_marca[1] == 'S') {
         printf("Localizada Descricao da base\n");
         ret = 'B';
         goto fim;
      }
   }

   hdr = (Hdr_bloco *)buf;

   if ( hdr->marca_fim[0] == 0x6 && hdr->marca_fim[1] == 0x4 ) {
      ret = hdr->tipo;
      switch( ret ) {
            case 'C' :  printf("Localizada Descricao de campos\n");
                        break;

            case 'V' :  printf("Localizada Descricao de Vistas\n");
                        break;

            case 'R' :  printf("Localizada Descricao de Relatorios\n");
                        break;

            case 'I' :  printf("Localizada Descricao de Itens de Vistas\n");
                        break;

            case 'L' :  printf("Localizada Descricao de Itens de Relatorios\n");
                        break;


      }
      *ordem = hdr->ident;
      goto fim;
   }
   else {
      fprintf(stderr, "Item de descricao de base desconhecido[%c %d]\n", hdr->tipo, hdr->tipo);
      ret = 0;
   }


fim :

   return ( ret );
}





COUNT trata_conteudo()
{  COUNT ret=0, dif;
   COUNT tam_usar;

   recupera_campos();

   /* Passa a gravar no arquivo de definicao de vistas */
   if ( tipo_exp == 'W' ) {
      fclose(fp_exp);
      fp_exp = fp_aux;
   }

   consiste_vistas();

   consiste_relats();


   tam_usar = GTVLEN(lb4_old, pos_stp);

   if ( RDVREC(lb4_old, pos_stp, buf_iotxt, tam_usar) != NO_ERROR ) {
      pos_stp = 0L;
   }
   else {

#ifdef FORMA_ANTIGA
      if ( release < 500 ) {
         dif = sizeof(struct hdtxt) - 6;
         pos_stp = NEWVREC(lb4_new, tam_usar + dif);

         w_memmove(buf_iotxt + dif, buf_iotxt, tam_usar );
         p_hdtxt = (struct hdtxt *)buf_iotxt;

         p_hdtxt->txt_marca   = MARCA_TEXTO;
         p_hdtxt->txt_record  = 0L;
         p_hdtxt->txt_campo   = 0;
         p_hdtxt->txt_parte   = 1;
         p_hdtxt->txt_proximo = (POINTER) 0L;

         WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar + dif);
      }
      else {
         pos_stp = NEWVREC(lb4_new, tam_usar);
	      WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar);
      }
#else


      p_hdtxt = (struct hdtxt *)buf_iotxt;
      if (  p_hdtxt->txt_marca   == MARCA_TEXTO &&
      		p_hdtxt->txt_record  == 0L &&
      		p_hdtxt->txt_campo   == 0 &&
      		p_hdtxt->txt_parte   == 1 &&
      		p_hdtxt->txt_proximo == (POINTER) 0L)  {
      	pos_stp = NEWVREC(lb4_new, tam_usar);
    		WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar);
    	}
    	else {
         dif = sizeof(struct hdtxt) - 6;
         pos_stp = NEWVREC(lb4_new, tam_usar + dif);

         w_memmove(buf_iotxt + dif, buf_iotxt, tam_usar );
         p_hdtxt = (struct hdtxt *)buf_iotxt;

         p_hdtxt->txt_marca   = MARCA_TEXTO;
         p_hdtxt->txt_record  = 0L;
         p_hdtxt->txt_campo   = 0;
         p_hdtxt->txt_parte   = 1;
         p_hdtxt->txt_proximo = (POINTER) 0L;

         WRTVREC(lb4_new, pos_stp, (TEXT *) buf_iotxt, tam_usar + dif);
    	}
#endif

   }

   WBS->bs_swpos = pos_stp;


   if ( tipo_exp == 'D' ) {
      fprintf(fp_exp,"   ### StopWords \n");
      exporta_texto(buf_iotxt, tam_usar,  "      ", "");
   }
   else if ( tipo_exp == 'E' )
      exporta_texto(buf_iotxt, tam_usar, "@@SW ", "@@SWF");

   /** WWW falta SW para LBW */

   return(ret);
}

COUNT recupera_campos( )
{  COUNT ret, i;
   Campo *pc;

   if ( pos_campos == 0L ) {
      fprintf(stderr, "Nao existe vetor de campos\n");
      cv_exit(60);
   }

   WBS->bs_cppos = pos_campos;

   /* load em modo edicao para permitir operacoes */
   v_campos[BASE_EDIT] = NULL;

   if ( (v_campos[BASE_EDIT] = load_campos(BASE_EDIT, 'E')) == NULL ) {
      fprintf(stderr, "Erro na carga dos campos\n");
      cv_exit(61);
   }

   if ( (ret = qtd_vetcmp(BASE_EDIT)) == 0 ) {
      fprintf(stderr, "Nao existem campos\n");
      cv_exit(62);
   }

   switch(tipo_exp) {
      case 'D' : fprintf(fp_exp,"\n\n   ### Definicao dos Campos\n");
                  break;
      case 'E' : fprintf(fp_exp,"@@VCI\n");
                  break;
      case 'W' : fprintf(fp_exp,"@CP Campos:\n");
                  break;
   }


   for ( i = 0 ; i < qtd_vetcmp(BASE_EDIT) ; i++ ) {

      pc = pos_vetcmp(BASE_EDIT)[i];
      switch(tipo_exp) {
         case 'D' : d_imp_linha_cp(pc, fp_exp);
                    break;
         case 'E' : e_imp_linha_cp(pc, fp_exp);
                    break;
         case 'W' : w_imp_linha_cp(pc, fp_exp);
                    break;
      }
   }

   switch(tipo_exp) {
      case 'E' : fprintf(fp_exp,"@@VCF\n");
                  break;
   }

   printf("Concluida Exportacao dos Campos\n");

   return(ret);
}


COUNT consiste_vistas()
{  COUNT ret = -1, i, new_ordem, ind, x;
   Vista    **vet_vis, *pv;
   Vet_itens *vv_old;
   Vet_itens *vi;


   new_ordem = 1;
   WBS->bs_vspos = pos_vistas;

   /* load em modo edicao para permitir operacoes */
   vv_old = NULL;

   /* vetor antigo */
   if ( (vv_old = load_vistas(BASE_EDIT, 'E')) == NULL ) {
      fprintf(stderr, "Erro na carga das vistas. ===== Vou recriar ====\n");
      WBS->bs_vspos = 0L;
      vv_old = load_vistas(BASE_EDIT, 'E');
   }

   switch(tipo_exp) {
      case 'D' : fprintf(fp_exp,"\n\n   ### Definicao das Vistas\n");
                  break;
      case 'E' : fprintf(fp_exp,"@@DVI\n");
                  break;
      case 'W' :  /* fprintf(fp_exp,"@****************************VS Vistas:\n"); */
                  break;
   }



   vet_vis = (Vista **) vv_old->vi_vtit;  /* aponta para vetor de vistas */

   for ( i = 1 ; i <= MAX_VISTAS; i++ ) {

      pv = vet_vis[i-1];
      ind = i;

      if ( pv != NULL && i <= vv_old->vi_nelem) {
         ap_vista = *pv;
         for ( x = 1; x <= MAX_VISTAS; x++) {
            if ( pos_ivis[x] == pv->vis_itpos ) {
               ind = x;
               break;
            }
         }
      }
      else {
         continue;
      }

      /* tem itens localizados */
      if ( pos_ivis[ind] != 0L) {
         pv->vis_itpos = pos_ivis[ind];
         if ( (vi = load_itvis(pv, 'E')) == NULL ) {
            printf("Vista [%s] Descartada. Nao corregou itens da vista %d\n",
               ap_vista.vis_ident, i+1);
            continue;
         }
      }
      else {
         printf("Vista [%s] Descartada. Sem itens na vista %d\n",
            ap_vista.vis_ident, i+1);
         continue;
      }

      vi->vi_ident = new_ordem;

      switch(tipo_exp) {
         case 'D' : d_impit_vista(pv->vis_ident, vi);
                    break;
         case 'E' : e_impit_vista(pv->vis_ident, vi);
                    break;
         case 'W' : w_impit_vista(pv->vis_ident, vi);
                    break;
      }

      rlse_vet(vi);

      new_ordem++;

      printf("Vista [%s] exportada Ok\n", ap_vista.vis_ident);
   }

   switch(tipo_exp) {
      case 'E' : fprintf(fp_exp,"@@DVF\n");
                  break;
   }


fim :

   if ( vv_old != NULL ) {
      rlse_vet(vv_old);
   }

   return(ret);
}


COUNT consiste_relats()
{  COUNT ret = -1, i, new_ordem, ind, x;
   Rel      **vet_rel, *pr;
   Vet_itens *vv_old;
   Vet_itens *vi;


   new_ordem = 1;
   WBS->bs_rlpos = pos_relats;

   /* load em modo edicao para permitir operacoes */
   vv_old = NULL;

   /* vetor antigo */
   if ( (vv_old = load_rels(BASE_EDIT, 'E')) == NULL ) {
      fprintf(stderr, "Erro na carga das relats. ===== Vou recriar ====\n");
      WBS->bs_rlpos = 0L;
      vv_old = load_rels(BASE_EDIT, 'E');
   }

   switch(tipo_exp) {
      case 'D' : fprintf(fp_exp,"\n\n   ### Definicao dos Relatorios\n");
                  break;
      case 'E' : fprintf(fp_exp,"@@DRI\n");
                  break;
      case 'W' :  fprintf(fp_exp,"@****************************VS Relatorios:\n");
                  break;
   }



   vet_rel = (Rel **) vv_old->vi_vtit;  /* aponta para vetor de relats */

   for ( i = 1 ; i <= MAX_VISTAS; i++ ) {

      pr = vet_rel[i-1];
      ind = i;

      if ( pr != NULL && i <= vv_old->vi_nelem) {
         ap_rel = *pr;
         for ( x = 1; x <= MAX_VISTAS; x++) {
            if ( pos_irel[x] == pr->rel_itpos ) {
               ind = x;
               break;
            }
         }
      }
      else {
         continue;
      }

      /* tem itens localizados */
      if ( pos_irel[ind] != 0L) {
         pr->rel_itpos = pos_irel[ind];
         if ( (vi = load_itrel(pr, 'E')) == NULL ) {
            printf("Rel. [%s] Descartado. Nao corregou itens do relat %d\n",
               ap_rel.rel_ident, i+1);
            continue;
         }
      }
      else {
         printf("Rel. [%s] Descartado. Sem itens no relatorio %d\n",
            ap_rel.rel_ident, i+1);
         continue;
      }

      vi->vi_ident = new_ordem;

      switch(tipo_exp) {
         case 'D' : d_impit_rel(pr->rel_ident, vi);
                    break;
         case 'E' : e_impit_rel(pr->rel_ident, vi);
                    break;
         case 'W' : w_impit_rel(pr->rel_ident, vi);
                    break;
      }

      rlse_vet(vi);

      new_ordem++;

      printf("Rel. [%s] Exportado Ok.\n", ap_rel.rel_ident);
   }

   switch(tipo_exp) {
      case 'E' : fprintf(fp_exp,"@@DRF\n");
                  break;
   }


fim :

   if ( vv_old != NULL ) {
      rlse_vet(vv_old);
   }

   return(ret);
}





/*======================================================================
========================================================================
                            lb2but.c
========================================================================
=======================================================================*/


/*---------------------------------------------------------------------*/
/*   C A M P O S                                                       */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_campos(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max, nelem, i;
   UCOUNT qtd_max;
   Campo **vetcmp, *pc;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_CAMPOS;
      qtd_max = sizeof(Campo) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Campo) * (el_max + 1);
   }

   v = load_vet('C', 0, modo, v_bases[sele]->bs_cppos, el_max, qtd_max);

   if ( v != NULL ) {
      vetcmp = (Campo **)v->vi_vtit;
      nelem  = v->vi_nelem;
      for ( i = 0; i < nelem; i++) {
         pc = vetcmp[i];
         pc->cp_olddata = NULL;
         pc->cp_newdata = NULL;
         pc->cp_oldtam  = 0;
         pc->cp_newtam  = 0;
         pc->cp_adoc    = NULL;
         pc->cp_pttab   = NULL;
      }
   }

   return(v);
}

F__GLB   VOID rlse_campos(sele)
COUNT sele;
{
   if ( v_campos[sele] != NULL ) {
      rlse_vet(v_campos[sele]);
      v_campos[sele] = NULL;
   }
}


F__GLB   Campo **pos_vetcmp(sele)
COUNT sele;
{

   if ( v_campos[sele] != NULL )
      return((Campo **)v_campos[sele]->vi_vtit);
   else
      return((Campo **)NULL);
}


F__GLB   COUNT qtd_vetcmp(sele)
COUNT sele;
{
   if ( v_campos[sele] != NULL )
      return(v_campos[sele]->vi_nelem);
   else
      return(0);
}


F__GLB   COUNT acha_campo( sele, num )
COUNT sele, num;
{  COUNT  ret, i;
   Campo **campos;

   campos = pos_vetcmp(sele);

   ret = -1;

   for( i = 0;  i  <  qtd_vetcmp(sele);  i++ ) {
      if ( campos[i]->cp_num  ==  num ) {
         ret = i;
         break;
      }
   }

   return ( ret );
}


/*---------------------------------------------------------------------*/
/*   V I S T A S                                                       */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_vistas(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_VISTAS;
      qtd_max = sizeof(Vista) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Vista) * (el_max + 1);
   }

   v = load_vet('V', 0, modo, v_bases[sele]->bs_vspos, el_max, qtd_max);

   return(v);
}




F__GLB   Vet_itens *load_itvis(vista, flag)
Vista *vista;
COUNT flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = ap_mxelem;
      qtd_max = ap_sizeio;   /* sizeof(TTela) * el_max; nao pode por ter final variavel */
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(TTela) * (el_max + 1);
   }

   v = load_vet('I', 0, modo, vista->vis_itpos, el_max, qtd_max);


   if ( ap_extravet > 0 ) {
      debug("Extra vet");
   }

   ap_extravet = 0;

   return(v);
}



F__GLB   TTela *pos_itvis(num)
COUNT num;
{

   if ( ap_vista.vis_vet->vi_vtit  != NULL )
      return((TTela *)ap_vista.vis_vet->vi_vtit[num]);
   else
      return((TTela*)NULL);
}

F__GLB   COUNT qtd_itvis()
{
   if ( ap_vista.vis_vet->vi_vtit  != NULL )
      return(ap_vista.vis_vet->vi_nelem);
   else
      return(0);
}




/*---------------------------------------------------------------------*/
/*   R E L A T O R I O S                                               */
/*---------------------------------------------------------------------*/

F__GLB   Vet_itens *load_rels(sele, flag)
COUNT sele, flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = MAX_REL;
      qtd_max = sizeof(Rel) * (el_max + 1);
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(Rel) * (el_max + 1);
   }

   v = load_vet('R', 0, modo, v_bases[sele]->bs_rlpos, el_max, qtd_max);


   return(v);
}




F__GLB   Vet_itens *load_itrel(rel, flag)
Rel *rel;
COUNT flag;
{  COUNT modo, el_max;
   UCOUNT qtd_max;
   Vet_itens *v;

   if ( flag == 'E' ) {
      modo = 'E';
      el_max = ap_mxelem;
      qtd_max = ap_sizeio;   /* sizeof(RTela) * el_max; nao pode por ter final variavel */
   }
   else {
      modo = 'F'; /* fixo */
      el_max = 0 ;  /* a funcao descobre */
      qtd_max = sizeof(RTela) * (el_max + 1);
   }

   v = load_vet('L', 0, modo, rel->rel_itpos, el_max, qtd_max);


   return(v);
}



F__GLB   RTela *pos_itrel(num)
COUNT num;
{

   if ( ap_rel.rel_vet->vi_vtit  != NULL )
      return((RTela *)ap_rel.rel_vet->vi_vtit[num]);
   else
      return((RTela*)NULL);
}

F__GLB   COUNT qtd_itrel()
{
   if ( ap_rel.rel_vet->vi_vtit  != NULL )
      return(ap_rel.rel_vet->vi_nelem);
   else
      return(0);
}





/*======================================================================
========================================================================
                            lb2vetut.c
========================================================================
=======================================================================*/



/*#  ---------------------------------------------------------------------
**#   Funcao...: load_vet
**#   Objetivo.: Carregar em memoria um bloco de elementos
**#   Entrada..: Parametros Abaixo
**#   Retorna..: Ponteiro para estrutura alocada ou NULL se Erro
**#
**#      onde : tipo -> 'C' - Campos
**#                  -> 'V' - Vistas
**#                  -> 'R' - Relatorio
**#                  -> 'I' - Itens de Vistas
**#                  -> 'E' - Itens de Relatorio
**#                  -> 'A' - Acessos
**#      onde : Ident-> Numero de identificacao do vetor
**#      onde : modo -> 'F' - Fixo. Nada pode ser alterado
**#                  -> 'E' - Itens podem ser modificados (edicao)
**#      onde : fd_arq   ->  file_descriptor do arquivo
**#      onde : file_pos ->  Posicao em disco do bloco com itens. Se NULL
**#                          inicaliza bloco.
**#      onde : tam_max  ->  Tamanho a ser alocado   em caso de edicao
**#      onde : max_elem ->  Maximo de elementos     em caso de edicao
**/

F__GLB   Vet_itens *load_vet(tipo, ident, modo, pos, max_elem, max_tam)
COUNT tipo, ident;
TEXT modo;
POINTER pos;
COUNT max_elem;
UCOUNT max_tam;
{  COUNT ret, tam, i, libera_buf;
   TEXT *buf_le;
   Vet_itens *vti;
   UCOUNT qtd_buf, qtd_ptr, tam_usar;
   Hdr_bloco hdr;
   TEXT *p1, *p2;
   UTEXT *p;

   ret = 0;
   p1 = p2 = NULL;
   vti = (Vet_itens *)NULL;
   ap_extravet = 0;

   buf_le = buf_iotxt;
   libera_buf = 0;   /* nao tem buffer alocado. so o faz se buf_iotxt for pequeno */

   memset(&hdr, '\0', sizeof(hdr));
   memset(buf_le, '\0', (UCOUNT)SIZE_IOTXT);


   /* primeiro verifica se em posicionamento tem header valido */

   if ( pos != 0L ) {
      tam_usar = GTVLEN(lb4_old, pos);
      if ( tam_usar > ap_sizeio ) {
         if ( (buf_le = malloc(tam_usar+10)) == NULL ) { /* 10 e folga */
            ret = -3; /* Sem memoria */
            goto fim;
         }
         libera_buf = 1;
      }


      if ( RDVREC(lb4_old, pos, buf_le, tam_usar) != NO_ERROR ) {
         ret = -1; /* nao tem header */
         goto fim;
      }

      memcpy(&hdr, buf_le, sizeof(hdr));

      /* verifica se em posicionamento tem bloco solicitado */
      if ( hdr.marca_fim[0] != 0x6 || hdr.marca_fim[1] != 0x4 ) {
         ret = -1; /* header invalido */
         goto fim;
      }
      if ( hdr.tipo != tipo || ( ident != 0 && hdr.ident != ident) ) {
         ret = -2; /* Bloco solicitado nao confere com posicionamento */
         goto fim;
      }

      ident = hdr.ident;
   }

   /* IDENTIFICA SE E VERSAO 1.5 */

   /* Calcula quantidade de memoria a ser alocada para o bloco */

   if ( modo == EDIT_OK )  {
      qtd_ptr = max_elem;
      qtd_buf = max_tam;
   }
   else {
      qtd_ptr = hdr.num_elementos;
      qtd_buf = hdr.tamanho;
   }


   /* aloca estrutura controle + area ponteiros + area info */
   if ( !(vti = (Vet_itens *) malloc(sizeof(Vet_itens)))) {
      ret = -3; /* Sem memoria */
      goto fim;
   }

   p1 = calloc(sizeof(TEXT *), qtd_ptr+1);
   p2 = malloc(qtd_buf + TAMANHO_HDR + 10 ); /* 10 e folga */

   if ( p1 == NULL || p2 == NULL ) {
      ret = -3; /* Sem memoria */
      goto fim;
   }


   /* Leitura do bloco propriamente dito */
   if ( lb4_old > 0  && pos != 0) {
      memcpy(p2 + TAMANHO_HDR, buf_le + TAMANHO_HDR, hdr.tamanho);
      /* verifica se informacao extra no bloco. Atualiza em ap_extravet */
      /* se existir deixar a mesma em buf_iotxt */
      ap_extravet = tam_usar - hdr.tamanho - TAMANHO_HDR;
   }
   else {
      hdr.tamanho = 0;
      hdr.num_elementos = 0;
   }

   vti->vi_tipo    = tipo;
   vti->vi_ident   = ident;
   vti->vi_status  = (modo == EDIT_OK) ? VET_EDIT : 0;

   vti->vi_pos     = pos;
   vti->vi_ftam    = TAMANHO_HDR + hdr.tamanho;

   vti->vi_mmax    = qtd_buf;
   vti->vi_nmax    = qtd_ptr;

   vti->vi_buffer  = p2 + TAMANHO_HDR;
   vti->vi_vtit    = (TEXT **)p1;

   vti->vi_mtam    = 0;
   vti->vi_nelem   = 0;
   vti->vi_curr    = 0;
   vti->vi_clen    = 0;

   /* monta vetor de ponteiros para informacoes */

   for ( i = 0, p = (UTEXT*) vti->vi_buffer; i < hdr.num_elementos; i++ ) {
      tam = (COUNT)GET_LONG(p);
      p += TAM_TAM;   /* faz apontar para tamanho do item corrente */

      tam = TAM_ITEM(tam);

      vti->vi_vtit[i] = (TEXT *)p;
      p += tam;

      vti->vi_mtam += (tam + TAM_TAM);
      vti->vi_nelem++;
   }


fim :

   if ( ret < 0 ) {
      if ( p2  != NULL ) free(p2);
      if ( p1  != NULL ) free(p1);
      if ( vti != NULL ) free(vti);
      vti = NULL;
   }
   else {
      if ( ap_extravet > 0 )  {
         p1 = buf_le + TAMANHO_HDR + hdr.tamanho;
         memcpy(buf_iotxt, p1, ap_extravet);
      }
   }

   if ( libera_buf ) free(buf_le);

   return(vti);
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: rlse_vet
**#   Objetivo.: Libera memoria utilizada por uma lista
**#
**/
F__GLB   VOID rlse_vet(vti)
Vet_itens *vti;
{  TEXT *p1;
   if ( vti != NULL ) {
      p1 = vti->vi_buffer;
      if ( p1 != NULL ) free(p1 - TAMANHO_HDR);
      if ( vti->vi_vtit   != NULL ) free(vti->vi_vtit);
      free(vti);
   }
}




/*#  ---------------------------------------------------------------------
**#   Funcao...: frs_item
**#   Objetivo.: Retorna endereco de memoria do primeiro item
**#
**/
F__GLB   VOID *fst_item(vti)
Vet_itens *vti;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || vti->vi_nelem < 1 ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr = 0;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}




/*#  ---------------------------------------------------------------------
**#   Funcao...: nxt_item
**#   Objetivo.: Retorna endereco de memoria do proximo item
**#
**/
F__GLB   VOID *nxt_item(vti)
Vet_itens *vti;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || (vti->vi_curr + 1) >= vti->vi_nelem  ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr++;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}



/*#  ---------------------------------------------------------------------
**#   Funcao...: pos_item
**#   Objetivo.: Retorna endereco de memoria do item mencionado
**#
**/
F__GLB   VOID *pos_item(vti, pos)
Vet_itens *vti;
COUNT pos;
{  VOID *p_ret;
   UTEXT *p;

   if ( vti == NULL || pos >= vti->vi_nelem || pos < 0  ) {
      p_ret = NULL;
   }
   else {
      vti->vi_curr = pos;

      p_ret = vti->vi_vtit[vti->vi_curr];

      if (p_ret == NULL )
         debug("vi_vtit[*] == NULL");

      p = p_ret;
      vti->vi_clen = (COUNT)GET_LONG((p-TAM_TAM));
   }

   return(p_ret);
}








VOID cv_exit(cod)
COUNT cod;
{
   exit(cod);
}







COUNT sai_linha(num, tipo, str)
COUNT num;
TEXT *tipo, *str;
{
   fprintf(fp_exp, "%10.10d %-15.15s 00001 %s\n", num, tipo, str);
   return(0);
}



COUNT exporta_texto(buf_in, tam, tok, tokfim)
TEXT *buf_in;
COUNT tam;
TEXT *tok, *tokfim;
{  TEXT *p;
   COUNT i, imprimiu=0;

   if ( tipo_exp == 'E' || tipo_exp == 'D') {

      p = buf_in;
      i = 0;

      if ( *(UTEXT *)p == MARCA_TEXTO ) {
         p += sizeof(struct hdtxt);
         i += sizeof(struct hdtxt);
      }

      for ( ; i < tam; i++) {
         if ( buf_in[i] == 0x0a ) {
            if ( (UTEXT)buf_in[i-1] == 0XFE ) {
               if ( i > 6 && buf_in[i-6] == 0X5 && buf_in[i-2] == 0X6 ) {
                  /* retira marca de margem */
                  buf_in[i-6] = 0XFE;
                  buf_in[i-5] = 0X0;
               }
            }
            buf_in[i] = 0X0;
         }

         if (buf_in[i] == '\0' ) {
            fprintf(fp_exp,"%s%s\n", tok, p);
            imprimiu = 1;
            p = &buf_in[i] + 1;
         }
      }

      if ( imprimiu && tokfim[0] != '\0')
         fprintf(fp_exp,"%s\n", tokfim);

   }

   return(0);
}


VOID sintaxe()
{
   printf("\n\nSintaxe : exporta [nomebase] [-DLW] [-PDiretorio_da_base] [-ODiretorio_de_saida]\n");
   printf("    -D Exportacao no formato de documentacao\n");
   printf("    -L Exportacao no formato de importacao do LightBase (DOS/UNIX)\n");
   printf("    -W Exportacao no formato de importacao do LightBase for Windows\n");
   printf("    -P Diretorio onde se encontra a base\n");
   printf("    -O Diretorio onde sera gravado arquivo de exportacao\n\n");

}

