#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"

#include  <string.h>

extern COUNT order;
extern COUNT tipo_exp;



#define   DISP_VIEWBACK "12632256"
#define   DISP_VIEWFORE "8388608"
#define   DISP_EDITBACK "12632256"
#define   DISP_EDITFORE "8388608"
#define   EDIT_VIEWBACK "12632256"
#define   EDIT_VIEWFORE "0"
#define   EDIT_EDITBACK "16777215"
#define   EDIT_EDITFORE "0"
#define   FX 8
#define   FY 20
#define   NOME_FONTE "Courier"
#define   TAM_FONTE "10"

#ifdef MSDOS
   VOID w_imp_linha_cp(Campo *, FILE *);
   COUNT w_impit_vista( TEXT *, Vet_itens * );
   COUNT w_impit_rel( TEXT *, Vet_itens * );
   VOID tira_virgula(TEXT *);
   COUNT acha_campo(COUNT, COUNT);
   Campo **pos_vetcmp(COUNT);
   COUNT sai_linha(COUNT, TEXT *, TEXT *);
   COUNT sai_campo(COUNT *, COUNT, COUNT, COUNT, COUNT, COUNT, TEXT *, COUNT);
#else
   VOID w_imp_linha_cp( );
   COUNT w_impit_vista( );
   COUNT w_impit_rel( );
   VOID tira_virgula( );
   COUNT acha_campo( );
   Campo **pos_vetcmp( );
   COUNT sai_linha( );
   COUNT sai_campo( );
#endif

VOID w_imp_linha_cp(pc, fp)
Campo *pc;
FILE *fp;
{  TEXT tipo[30], desc[50], indexa[20];
   COUNT tam;

   strcpy(desc, pc->cp_desc);
      tira_virgula(desc);

   if (desc[0] == '\0')
      strcpy(desc,pc->cp_nome);

   switch(pc->cp_tipo) {
      case 'T' : strcpy(tipo, "Documento");        strcpy(indexa,"Textual");   break;
      case 'N' : strcpy(tipo, "Num�rico");          strcpy(indexa,"Por Campo");   break;
      case 'x' : strcpy(tipo, "Alfanum�rico");     strcpy(indexa,"Textual");   break;
      case 'F' : strcpy(tipo, "Num�rico");          strcpy(indexa,"Textual");   break;
      case 'D' : strcpy(tipo, "Data");             strcpy(indexa,"Por Campo");   break;
      case 'H' : strcpy(tipo, "Hora");             strcpy(indexa,"Por Campo");   break;
      case 'd' : strcpy(tipo, "Data");             strcpy(indexa,"Por Campo");   break;
      case 'h' : strcpy(tipo, "Hora");             strcpy(indexa,"Por Campo");   break;
   }

   if ( pc->cp_indexavel != 'S')
      strcpy(indexa,"Sem Indice");

   tam = pc->cp_mhor;

   if ( pc->cp_tipo == 'T' ||  pc->cp_tipo == 'N' || pc->cp_tipo == 'F' )
      tam = 0;


   fprintf(fp,".%s,%s,%s,%d,N�o Multivalorado,%s,\n",
      desc,
      pc->cp_nome,
      tipo,
      tam,
      indexa);

   if ( pc->cp_tipo == 'N' ) {
      fprintf(fp," FR:Byte\n");
      fprintf(fp," CD:%d\n", pc->cp_decimais);
   }

   if ( pc->cp_tipo == 'F' ) {
      fprintf(fp," FR:Byte\n");
      fprintf(fp," CD:%d\n", pc->cp_decimais);
      fprintf(fp," V:@@FORMULA,%s\n", pc->cp_mascara);
   }

   switch(pc->cp_tipo) {
      case 'D' :
      case 'd' : fprintf(fp," M:dd/mm/yy\n");  break;
      case 'H' :
      case 'h' : fprintf(fp," M:hh:mm\n");  break;
      case 'F' :
      case 'N' :
      case 'T' : break;
      default  : fprintf(fp," M:%s\n", pc->cp_mascara);  break;

   }

   if ( pc->cp_rodape[0] == '@' ) {
      fprintf(fp," @@RODAPE:%s\n", pc->cp_rodape);
   }


   if ( pc->cp_critica != 0 && pc->cp_critica != 'N') {
      switch(pc->cp_critica) {
         case 'T' : fprintf(fp," V:TABELA,@@Campo,LBWD@@[%s],DEFUDB,Local Host\n", pc->cp_param.tab_auto.tabela); break;
         case 'I' : fprintf(fp," @@V:INTERVALO,%s,%s\n", pc->cp_param.intervalo.cp_minimo, pc->cp_param.intervalo.cp_maximo); break;
         case 'G' : fprintf(fp," V:CGC\n"); break;
         case 'C' : fprintf(fp," V:CPF\n"); break;
         case 'A' : fprintf(fp," @@V:AUTONUM\n"); break;
         case 'M' : fprintf(fp," V:MOD11\n"); break;
      }
   }

}





F__LOC   COUNT w_impit_vista(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret, ind, reg=1, nitens,i ;
   static COUNT form;
   TTela *pe;
   TEXT *p, tipo[20], aux[80], sreg[20];
   Campo *pc;

   ret = 0;

   form = 1;
   order = 1;

   /* conta numero de intens na vista que serao exportados */
   for (ind = 0,nitens =0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){

      if ( pe->te_tipo == 'S' || pe->te_tipo == 'E' ) {
         i = acha_campo(BASE_EDIT, pe->te_num );
         pe->te_ivetcp = i;
      }

      switch ( pe->te_tipo ) {
         case 'D':
                   nitens++;
                   break;
         case 'E':
         case 'S':
                   pc = pos_vetcmp(pe->te_icb)[pe->te_ivetcp];
                   if ( pc->cp_tipo == 'A' || pc->cp_tipo == 'x' || pc->cp_tipo == 'T'  );
                      nitens++;
                   break;
      }
   }




   sai_linha(reg, "Type",           "0");
   sprintf(aux, "%d", form);
   sai_linha(reg, "FormId",         aux);
   sprintf(aux, "%d", nitens);
   sai_linha(reg, "RegId",          aux);
   sai_linha(reg, "Name",           nome);
   sai_linha(reg, "ViewBackColor",  DISP_VIEWBACK);
   sai_linha(reg, "XCoord",         "0");
   sai_linha(reg, "YCoord",         "0");
   sai_linha(reg, "Height",         "440");
   sai_linha(reg, "Width",          "656");

   for (ind = 0; (pe = (TTela *)vi->vi_vtit[ind]) != NULL; ind++ ){

      p = ( SC * ) pe + sizeof( TTela );

      switch ( pe->te_tipo ) {

         case 'B' :
                     break;

         case 'D' :
                     sprintf(sreg, "%d", ++reg);
                     sai_linha(reg, "Type",           "1");
                     sai_linha(reg, "FormId",         "0");
                     sai_linha(reg, "RegId",          sreg);
                     sai_linha(reg, "ControlOrder",   "-1");
                     sai_linha(reg, "Caption",        p);
                     sai_linha(reg, "ViewBackColor",  DISP_VIEWBACK);
                     sai_linha(reg, "ViewForeColor",  DISP_VIEWFORE);
                     sai_linha(reg, "EditBackColor",  DISP_EDITBACK);
                     sai_linha(reg, "EditForeColor",  DISP_EDITFORE);
                     sai_linha(reg, "EditBorder",     "0");
                     sai_linha(reg, "ViewBorder",     "0");
                     sai_linha(reg, "Style",          "384");

                     sprintf(aux, "%d", pe->te_coluna * FX);
                     sai_linha(reg, "XCoord",         aux);

                     sprintf(aux, "%d", pe->te_linha * FY);
                     sai_linha(reg, "YCoord",         aux);

                     sprintf(aux, "%d", FY);
                     sai_linha(reg, "Height",         aux);
                     sprintf(aux, "%d", strlen(p) * FX);
                     sai_linha(reg, "Width",         aux);

                     sai_linha(reg, "CaracterSet",         NOME_FONTE);
                     sai_linha(reg, "CaracterSet",         "~`!@#$%^&*()-+|=-TeCfMt");
                     sai_linha(reg, "CaracterSet",         "0,0");
                     sai_linha(reg, "CaracterSize",        TAM_FONTE);

                     break;

         case 'H' :
         case 'L' :
                     break;

         case 'E' :
         case 'S' :
                     if ( pe->te_tipo == 'E' ) strcpy(tipo, "CAMPO_E");
                     else                      strcpy(tipo, "CAMPO_S");

                     pc = pos_vetcmp(pe->te_icb)[pe->te_ivetcp];

                     sai_campo(&reg, pe->te_tipo, pe->te_linha, pe->te_coluna, pe->te_vver, pe->te_vhor,pc->cp_nome, pc->cp_tipo);

                     break;

      };

   };

fim :

   return(ret);
}

F__LOC   COUNT w_impit_rel(nome, vi )
TEXT *nome;
Vet_itens *vi;
{  COUNT ret=0;


   nome=nome;
   vi=vi;

fim :

   return(ret);
}


COUNT sai_campo(end_reg, es, lin, col, vver, vhor, nome, tipo_cp)
COUNT *end_reg;
COUNT es, lin, col, vver, vhor;
TEXT *nome;
COUNT tipo_cp;
{  TEXT aux[50];
   TEXT sreg[20];
   COUNT reg;


   switch(tipo_cp) {
      case 'T' :
      case 'A' :
      case 'x' :
            reg = *end_reg;
            reg++;
            *end_reg= reg;

            sprintf(sreg, "%d", reg);

            if ( tipo_cp == 'T' )
               sai_linha(reg, "Type",           "6");
            else
               sai_linha(reg, "Type",           "5");

            sai_linha(reg, "FormId",         "0");
            sai_linha(reg, "RegId",          sreg);
            sprintf(aux, "%d", order++);
            sai_linha(reg, "ControlOrder",   aux);
            sprintf(aux, "Item%s", sreg);
            sai_linha(reg, "Name",           aux);
            sai_linha(reg, "Description", "" );
            sai_linha(reg, "Description", "~`!@#$%^&*()-+|=-TeCfMt" );
            sai_linha(reg, "Description", "0,0" );
            sai_linha(reg, "Help", "" );
            sai_linha(reg, "Help", "~`!@#$%^&*()-+|=-TeCfMt" );
            sai_linha(reg, "Help", "0,0" );
            sai_linha(reg, "ViewBackColor",  EDIT_VIEWBACK);
            sai_linha(reg, "ViewForeColor",  EDIT_VIEWFORE);
            sai_linha(reg, "EditBackColor",  EDIT_EDITBACK);
            sai_linha(reg, "EditForeColor",  EDIT_EDITFORE);
            sai_linha(reg, "EditBorder",     "4");
            sai_linha(reg, "ViewBorder",     "2");

            sprintf(aux, "%d", col * FX);
            sai_linha(reg, "XCoord",         aux);

            sprintf(aux, "%d", lin * FY);
            sai_linha(reg, "YCoord",         aux);

            sprintf(aux, "%d", vver * FY);
            sai_linha(reg, "Height",         aux);
            sprintf(aux, "%d", vhor * FX);
            sai_linha(reg, "Width",         aux);

            if ( tipo_cp == 'T' )
               sai_linha(reg, "DataType",           "3");
            else
               sai_linha(reg, "DataType",           "2");

            sai_linha(reg, "CaracterSet",         NOME_FONTE);
            sai_linha(reg, "CaracterSet",         "~`!@#$%^&*()-+|=-TeCfMt");
            sai_linha(reg, "CaracterSet",         "0,0");
            sai_linha(reg, "CaracterSize",        TAM_FONTE);

            sai_linha(reg, "FieldId",        nome);
            sai_linha(reg, "Source",         "1");
            sai_linha(reg, "Target",         "1");

            if ( es == 'E' )
               sai_linha(reg, "CanEdit",        "1");
            else
               sai_linha(reg, "CanEdit",        "0");

   }

   return(0);
}



VOID tira_virgula(str)
TEXT *str;
{  TEXT *p;

   p = str;

   while (*p) {
      if (*p == ',')
         *p=';';
      p++;
   }

}

