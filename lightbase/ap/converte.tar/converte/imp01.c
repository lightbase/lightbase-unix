#include  "lb2all.h"
#define   ARG    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#define   WIN    unsigned char    /* nas estruturas que usam nao sera necessario aqui */
#include  "lb2stru.h"
#include  "lb2vet.h"

#include  <string.h>
#include  <ctype.h>
#include  <time.h>

#ifdef MSDOS
#include  <mem.h>
#include  <dir.h>
#include  <io.h>
#endif

#ifdef MSDOS
COUNT le_linha(VOID);
VOID  cv_exit( COUNT );
COUNT ver_campo(COUNT, TEXT *, COUNT *);
COUNT recupera_sw(TEXT *);
COUNT recupera_ev(TEXT *);
#else
COUNT le_linha( );
VOID  cv_exit( );
COUNT ver_campo( );
COUNT recupera_sw( );
COUNT recupera_ev( );
#endif


extern TEXT *buf_io;
extern TEXT *buf_sw;
extern TEXT lin_token[];
extern TEXT *lin_info;
extern COUNT tam_info;
extern TEXT texto_aux[];
extern COUNT ap_extravet;
extern COUNT depura;

extern FILE *fpi;
extern COUNT fim_fpi;

extern LONG num_serie;
extern COUNT id_arq;

#define TAM_BUF 4000
#define CONST   1227 /* constante para mascarar numeros chaves da base (chute) */
#define     MARCA_TEXTO    255

extern struct hdtxt {
   UTEXT txt_marca;
   LONG  txt_record;
   UTEXT txt_campo;
   UTEXT txt_parte;
   POINTER txt_proximo;
} *p_hdtxt;




COUNT le_linha()
{  COUNT ret;
   TEXT *p;

   ret = 0;
   tam_info = 0;
   lin_info = "";

   if ( fgets(buf_io, TAM_BUF, fpi) != NULL ) {
      p = strchr(buf_io, '\0');
      if ( p != NULL && p > buf_io ) {
         if ( *(p-1) == 0x0a )
            *(p-1) = '\0';
      }
      p = strchr(buf_io, ' ');
      if ( p != NULL ) {
         *p = '\0';
         if ( strlen(buf_io) > 30) {
            fprintf(stderr, "Tamanho do token invalido %d\n", strlen(buf_io));
            cv_exit(1);
         }
         strcpy(lin_token, buf_io);
         *p = ' ';
         lin_info = p + 1;
         tam_info = strlen(lin_info);
         ret = (COUNT)(p - buf_io);
      }
      else {
         if ( strlen(buf_io) > 30 ) {
            fprintf(stderr, "Tamanho do token invalido %d\n", strlen(buf_io));
            cv_exit(1);
         }
         strcpy(lin_token, buf_io);
         lin_info = "";
         ret = strlen(buf_io);
      }

   }
   else
      fim_fpi = 1;

if ( depura == 2 )
   fprintf(stderr, "ret = %d  token = [%s]  lin_info = [%s]\n", ret, lin_token, lin_info);

   return(ret);
}



VOID carrega_defbase(pb)
Base *pb;
{  COUNT basicos = 0;
   time_t tempo;

   memset(pb, 0, sizeof(Base));


   time(&tempo);
   pb->bs_cr_data = tempo;

   pb->bs_marca[0] = 'B';
   pb->bs_marca[1] = 'S';



   if ( le_linha() > 0 && strcmp(lin_token, "@@BSI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@@BSF") == 0 )
            break;

         if      ( strcmp(lin_token, "NM") == 0 ) {
            if (tam_info <= 8 ) {
               strcpy(pb->bs_nome, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "DS") == 0 ) {
            if (tam_info <= TD ) {
               strcpy(pb->bs_desc, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "PT") == 0 ) {
            if (tam_info <= TD ) {
               strcpy(pb->bs_path, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "DN") == 0 ) {
            if (tam_info <= TE ) {
               strcpy(pb->bs_dono, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "GR") == 0 ) {
            if (tam_info <= TE ) {
               strcpy(pb->bs_grupo, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "CN") == 0 ) {
            int id, xor;
            int finger;
            LONG ns;
            sscanf(lin_info, "%d,%ld,%d,%d", &id, &ns, &xor, &finger);
            if ( id != 0 ) id -= CONST;
            if ( xor != 0 ) xor -= CONST;
            if ( finger != 0 ) finger -= CONST;
            pb->bs_idbase = id;
            pb->bs_nserie = ns;
            pb->bs_xor    = xor;
            pb->bs_finger = finger;
            basicos++;
         }
         else if ( strcmp(lin_token, "VR") == 0 ) {
            pb->bs_versao = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "SD") == 0 ) {
            pb->bs_sepdecimal = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "DC") == 0 ) {
            pb->bs_cr_data = atol(lin_info);
         }
         else if ( strcmp(lin_token, "DA") == 0 ) {
            pb->bs_al_data = atol(lin_info);
         }
         else if ( strcmp(lin_token, "DB") == 0 ) {
            pb->bs_bk_data = atol(lin_info);
         }
         else {
            fprintf(stderr, "Informacao nao reconhecida em BASE [%s]\n", buf_io);
         }
      }

   }

   if ( basicos < 8 ) {
      fprintf(stderr, "Falta Informacoes para construir Header da Base\n");
   }

   num_serie = pb->bs_nserie;
   id_arq    = pb->bs_idbase;

   return;
}



COUNT carrega_cp(pc)
Campo *pc;
{  COUNT ret = 0, basicos = 0;
   static COUNT numcp;


   memset(pc, 0, sizeof(Campo));

   pc->cp_ordem = numcp + 1;
   pc->cp_num   = numcp + 1;
   pc->cp_chave_unica = 'N';
   pc->cp_branco      = 'N';
   pc->cp_fonetica    = 'N';
   pc->cp_indexavel   = 'S';
   pc->cp_critica     = 'N';

   pc->cp_tpreg[0] = 'C';
   pc->cp_tpreg[1] = 'P';



   if ( le_linha() > 0 && strcmp(lin_token, "@@CPI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@@CPF") == 0 )
            break;

         if      ( strcmp(lin_token, "NM") == 0 ) {
            if (tam_info <= TE ) {
               strcpy(pc->cp_nome, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "DC") == 0 ) {
            pc->cp_decimais = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "DE") == 0 ) {
            if (tam_info <= TD ) {
               strcpy(pc->cp_desc, lin_info);
            }
         }
         else if ( strcmp(lin_token, "MH") == 0 ) {
            pc->cp_mhor = (UTEXT)atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "TP") == 0 ) {
            pc->cp_tipo = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "MS") == 0 ) {
            if (tam_info <= TM ) {
               strcpy(pc->cp_mascara, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "CU") == 0 ) {
            pc->cp_chave_unica = lin_info[0];
         }
         else if ( strcmp(lin_token, "CB") == 0 ) {
            pc->cp_branco = lin_info[0];
         }
         else if ( strcmp(lin_token, "CF") == 0 ) {
            pc->cp_fonetica = lin_info[0];
         }
         else if ( strcmp(lin_token, "CI") == 0 ) {
            pc->cp_indexavel = lin_info[0];
         }
         else if ( strcmp(lin_token, "CR") == 0 ) {
            if (tam_info <= 52 ) {
               strcpy(pc->cp_rodape, lin_info);
            }
         }
         else if ( strcmp(lin_token, "CH") == 0 ) {
            if (tam_info <= 9 ) {
               strcpy(pc->cp_help, lin_info);
            }
         }
         else if ( strcmp(lin_token, "CC") == 0 ) {
            pc->cp_critica = lin_info[0];
         }
         else if ( strcmp(lin_token, "VT") == 0 ) {
            if (tam_info <= 25 ) {
               strcpy(pc->cp_param.tab_auto.tabela, lin_info);
            }
         }
         else if ( strcmp(lin_token, "VM") == 0 ) {
            if (tam_info <= 25 ) {
               strcpy(pc->cp_param.intervalo.cp_maximo, lin_info);
            }
         }
         else if ( strcmp(lin_token, "Vm") == 0 ) {
            if (tam_info <= 25 ) {
               strcpy(pc->cp_param.intervalo.cp_minimo, lin_info);
            }
         }
         else if ( strcmp(lin_token, "VA") == 0 ) {
            if (tam_info <= 25 ) {
               strcpy(pc->cp_param.tab_auto.autonum, lin_info);
            }
         }
         else if ( strcmp(lin_token, "FM") == 0 ) {
            if (tam_info <= 30 ) {
               strcpy(pc->cp_param.cp_msc_form, lin_info);
            }
         }
         else if ( strcmp(lin_token, "OR") == 0 ) {
         }
         else if ( strcmp(lin_token, "NU") == 0 ) {
         }
         else {
            fprintf(stderr, "Informacao nao reconhecida na definicao de campos\n");
         }
      }

   }

   if ( strcmp(lin_token, "@@VCF") == 0 ) {
      ret = -1;
   }
   else if ( basicos < 5 ) {
      fprintf(stderr, "Falta Informacoes para construir campo\n");
      ret = 0;
   }
   else {
      ret = ++numcp;
   }

   return(ret);
}






COUNT carrega_vista(pv)
Vista *pv;
{  COUNT ret = 0, basicos = 0;

   memset(pv, 0, sizeof(Vista));

   if ( le_linha() > 0 && strcmp(lin_token, "@@VSI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@@VSF") == 0 )
            break;

         if      ( strcmp(lin_token, "VNO") == 0 ) {
            if (tam_info <= TD ) {
               strcpy(pv->vis_ident, lin_info);
            }
         }
         else if ( strcmp(lin_token, "VOR") == 0 ) {
            pv->vis_ordem = atoi(lin_info);
            basicos++;
         }
      }
   }

   if ( strcmp(lin_token, "@@DVF") == 0 ) {
      ret = -1;
   }
   else if ( basicos < 1 ) {
      fprintf(stderr, "Falta Informacoes para construir vista\n");
      ret = 0;
   }
   else {
      ret = 1;
   }

   return(ret);
}



COUNT carrega_itvista(PI)
TTela *PI;
{  COUNT ret = 0, basicos = 0, erro = 0, old_num = -1;
   static COUNT numcp;


   texto_aux[0] = '\0';
   memset(PI, '\0', sizeof(TTela));

   PI->te_append      = 'N';
   PI->te_tela        = 1;
   PI->te_num         = -1;
   PI->te_autoclear   = 'N';
   PI->te_obrigatorio = 'N';


   PI->te_base[0]     = '\0';
   PI->te_ivetcp      = -1;
   PI->te_icb         = BASE_EDIT;  /* ANANIAS @@@ */

   PI->te_tpreg[0] = 'I';
   PI->te_tpreg[1] = 'V';


   if ( le_linha() > 0 && strcmp(lin_token, "@IVI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@IVF") == 0 )
            break;

         if ( strcmp(lin_token, "CA") == 0 ) {
            PI->te_append = lin_info[0];
         }
         else if ( strcmp(lin_token, "TL") == 0 ) {
            PI->te_tela = atoi(lin_info);
         }
         else if ( strcmp(lin_token, "TP") == 0 ) {
               PI->te_tipo = lin_info[0];
               basicos++;
         }
         else if ( strcmp(lin_token, "LI") == 0 ) {
            PI->te_linha = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "CO") == 0 ) {
            PI->te_coluna = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "VV") == 0 ) {
            PI->te_vver = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "VH") == 0 ) {
            PI->te_vhor = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "AC") == 0 ) {
            PI->te_autoclear = lin_info[0];
         }
         else if ( strcmp(lin_token, "OB") == 0 ) {
            PI->te_obrigatorio = lin_info[0];
         }
         else if ( strcmp(lin_token, "TX") == 0 ) {
            strcpy(texto_aux, lin_info);
         }
         else if ( strcmp(lin_token, "NC") == 0 ) {
            COUNT num;
            ver_campo(BASE_EDIT,lin_info, &num);
            PI->te_num = num;
            if ( num < 0 ) {
               fprintf(stderr, "Campo [%s] nao existe na Base\n", lin_info);
               erro = 1;
            }
         }
         else if ( strcmp(lin_token, "NM") == 0 ) {
            if ( atoi(lin_info) == 0 )
               old_num = 0;
         }
         else {
            fprintf(stderr, "Informacao nao reconhecida na definicao de campos\n");
         }
      }

   }

   if ( erro ) {
      ret = 0;
      goto fim;
   }

   if ( strcmp(lin_token, "@@VIF") == 0 ) {
      ret = -1;
   }
   else if ( basicos < 5 ) {
      fprintf(stderr, "Falta Informacoes para construir itens de vista\n");
      ret = 0;
   }
   else {
      if (PI->te_tipo == 'B' || PI->te_tipo == 'D' || PI->te_tipo == 'H' || PI->te_tipo == 'V' )
         PI->te_num = old_num;
      ret = ++numcp;
   }

fim :

   return(ret);
}

/*=====================================================================*/


COUNT carrega_relat(pr)
Rel *pr;
{  COUNT ret = 0, basicos = 0;

   memset(pr, 0, sizeof(Rel));

   if ( le_linha() > 0 && strcmp(lin_token, "@@RLI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@@RLF") == 0 )
            break;

         if      ( strcmp(lin_token, "NO") == 0 ) {
            if (tam_info <= TD ) {
               strcpy(pr->rel_ident, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "OR") == 0 ) {
            pr->rel_ordem = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "NI") == 0 ) {
            pr->rel_n_elem = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "TI") == 0 ) {
            if (tam_info <= 51 ) {
               strcpy(pr->rel_titulo, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "RO") == 0 ) {
            if (tam_info <= 51 ) {
               strcpy(pr->rel_rodape, lin_info);
               basicos++;
            }
         }
         else if ( strcmp(lin_token, "TP") == 0 ) {
            pr->rel_tipo = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "CI") == 0 ) {
            pr->rel_cabec = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "NL") == 0 ) {
            pr->rel_linhas = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "NC") == 0 ) {
            pr->rel_colunas = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "IL") == 0 ) {
            pr->rel_l_inter = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "IC") == 0 ) {
            pr->rel_c_inter = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "NE") == 0 ) {
            pr->rel_n_etq = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "CA") == 0 ) {
            pr->rel_caracter = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "QL") == 0 ) {
            pr->rel_qualid = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "FS") == 0 ) {
            pr->rel_folha = lin_info[0];
            basicos++;
         }
         else if ( strcmp(lin_token, "O1") == 0 ) {
            TEXT campo[50], *p;
            int nlin;
            char ordem, totaliza;
            COUNT num;
            if ( (p = strchr(lin_info, ',')) != NULL ) {
               *p++ = '\0';
               strcpy(campo, lin_info);
               sscanf(p, "%c,%d,%c", &ordem, &nlin, &totaliza);
               ver_campo(BASE_EDIT,lin_info, &num);
               if ( num < 0 ) {
                  fprintf(stderr, "Campo [%s] nao existe na Base\n", campo);
               }
               else {
                  pr->rel_1numcampo = num;
                  pr->rel_1ord = ordem;
                  pr->rel_1linhas = nlin;
                  pr->rel_1total = totaliza;
               }
            }
         }
         else if ( strcmp(lin_token, "O2") == 0 ) {
            TEXT campo[50], *p;
            int nlin;
            char ordem, totaliza;
            COUNT num;
            if ( (p = strchr(lin_info, ',')) != NULL ) {
               *p++ = '\0';
               strcpy(campo, lin_info);
               sscanf(p, "%c,%d,%c", &ordem, &nlin, &totaliza);
               ver_campo(BASE_EDIT,lin_info, &num);
               if ( num < 0 ) {
                  fprintf(stderr, "Campo [%s] nao existe na Base\n", campo);
               }
               else {
                  pr->rel_2numcampo = num;
                  pr->rel_2ord = ordem;
                  pr->rel_2linhas = nlin;
                  pr->rel_2total = totaliza;
               }
            }
         }
         else if ( strcmp(lin_token, "O3") == 0 ) {
            TEXT campo[50], *p;
            int nlin;
            char ordem, totaliza;
            COUNT num;
            if ( (p = strchr(lin_info, ',')) != NULL ) {
               *p++ = '\0';
               strcpy(campo, lin_info);
               sscanf(p, "%c,%d,%c", &ordem, &nlin, &totaliza);
               ver_campo(BASE_EDIT,lin_info, &num);
               if ( num < 0 ) {
                  fprintf(stderr, "Campo [%s] nao existe na Base\n", campo);
               }
               else {
                  pr->rel_3numcampo = num;
                  pr->rel_3ord = ordem;
                  pr->rel_3linhas = nlin;
                  pr->rel_3total = totaliza;
               }
            }
         }
      }
   }

   if ( strcmp(lin_token, "@@DRF") == 0 ) {
      ret = -1;
   }
   else if ( basicos < 15 ) {
      fprintf(stderr, "Falta Informacoes para construir Relatorio");
      ret = 0;
   }
   else {
      ret = 1;
   }

   return(ret);
}



COUNT carrega_itrel(PI)
RTela *PI;
{  COUNT ret = 0, basicos = 0, erro = 0, old_num = -1;
   static COUNT numcp;


   texto_aux[0] = '\0';
   memset(PI, '\0', sizeof(RTela));

   PI->re_uv      = 0;
   PI->re_tela    = 1;

   PI->re_base[0]     = '\0';
   PI->re_ivetcp      = -1;
   PI->re_icb         = BASE_EDIT;  /* ANANIAS @@@ */

   PI->re_tpreg[0] = 'I';
   PI->re_tpreg[1] = 'R';


   if ( le_linha() > 0 && strcmp(lin_token, "@IRI") == 0 ) {

      while (le_linha() > 0 ) {
         if ( strcmp(lin_token, "@IRF") == 0 )
            break;

         if ( strcmp(lin_token, "UV") == 0 ) {
            PI->re_uv = atoi(lin_info);
         }
         else if ( strcmp(lin_token, "TL") == 0 ) {
            PI->re_tela = atoi(lin_info);
         }
         else if ( strcmp(lin_token, "TP") == 0 ) {
               PI->re_tipo = lin_info[0];
               basicos++;
         }
         else if ( strcmp(lin_token, "LI") == 0 ) {
            PI->re_linha = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "CO") == 0 ) {
            PI->re_coluna = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "VV") == 0 ) {
            PI->re_vver = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "VH") == 0 ) {
            PI->re_vhor = atoi(lin_info);
            basicos++;
         }
         else if ( strcmp(lin_token, "TO") == 0 ) {
            PI->re_tot = lin_info[0];
         }
         else if ( strcmp(lin_token, "QT") == 0 ) {
            PI->re_quant = lin_info[0];
         }
         else if ( strcmp(lin_token, "MD") == 0 ) {
            PI->re_media = lin_info[0];
         }
         else if ( strcmp(lin_token, "DV") == 0 ) {
            PI->re_desvio = lin_info[0];
         }
         else if ( strcmp(lin_token, "TX") == 0 ) {
            strcpy(texto_aux, lin_info);
         }
         else if ( strcmp(lin_token, "NC") == 0 ) {
            COUNT num;
            ver_campo(BASE_EDIT,lin_info, &num);
            PI->re_num = num;
            if ( num < 0 ) {
               fprintf(stderr, "Campo [%s] nao existe na Base\n", lin_info);
               erro = 1;
            }
         }
         else if ( strcmp(lin_token, "NM") == 0 ) {
            if ( atoi(lin_info) == 0 )
               old_num = 0;
         }
         else {
            fprintf(stderr, "Informacao nao reconhecida na definicao de campos\n");
         }
      }

   }

   if ( erro ) {
      ret = 0;
      goto fim;
   }

   if ( strcmp(lin_token, "@@EVI") == 0 ) { /* extravet */
      recupera_ev(buf_sw);
   }

   if ( strcmp(lin_token, "@@RIF") == 0 ) {
      ret = -1;
   }
   else if ( basicos < 5 ) {
      fprintf(stderr, "Falta Informacoes para construir itens de vista\n");
      ret = 0;
   }
   else {
      if (PI->re_tipo == 'B' || PI->re_tipo == 'D' || PI->re_tipo == 'H' || PI->re_tipo == 'V' )
         PI->re_num = old_num;
      ret = ++numcp;
   }

fim :

   return(ret);
}



COUNT recupera_sw(dest)
TEXT *dest;
{  TEXT *pd;
   COUNT ret = 0, lin = 0, tam = 0;

   *dest = '0';

   pd = dest;
   pd += sizeof(struct hdtxt);

if ( depura ) {
	fprintf(stderr, "Entrada em recupera SW\n");
	depura = 2;
}
volta:

   while ( le_linha() > 0 && strcmp(lin_token, "@@SW") == 0 ) {
      if ( lin++ ) {
         pd = strchr(pd, '\0');
         *pd++ = 0x0a;
         *pd   = 0x0;
         tam++;
      }
if ( depura )
	fprintf(stderr, "linha SW : [%s] tam = %d\n", lin_info, tam);
      strcpy(pd, lin_info);
      tam += strlen(lin_info);
   }

if ( strcmp(lin_token, "@@DRF") == 0 )
   goto volta;
if ( strcmp(lin_token, "@@DVF") == 0 )
   goto volta;


   if (lin > 1 )
      tam++;


   p_hdtxt = (struct hdtxt *)dest;

if ( depura )
   fprintf(stderr, "tam final em  SW :  %d\n", tam);
   if ( tam > 2 ) {
      p_hdtxt->txt_marca   = MARCA_TEXTO;
      p_hdtxt->txt_record  = 0L;
      p_hdtxt->txt_campo   = 0;
      p_hdtxt->txt_parte   = 1;
      p_hdtxt->txt_proximo = (POINTER) 0L;
   }

   ret = tam + sizeof(struct hdtxt);

   return(ret);
}


COUNT recupera_ev(dest)
TEXT *dest;
{  TEXT *pd;
   COUNT ret = 0, lin = 0, tam = 0;

   *dest = '0';

   pd = dest;

   while ( le_linha() > 0 && strcmp(lin_token, "@@EV") == 0 ) {
      if ( lin++ ) {
         pd = strchr(pd, '\0');
         *pd++ = 0x0a;
         *pd   = 0x0;
         tam++;
      }
      strcpy(pd, lin_info);
      tam += strlen(lin_info);
   }

   if (lin > 1 )
      tam++;

   ap_extravet = ret = tam;

   return(ret);
}

